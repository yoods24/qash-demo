<div class="fi-app">
    {{ $this->table }}
</div>
