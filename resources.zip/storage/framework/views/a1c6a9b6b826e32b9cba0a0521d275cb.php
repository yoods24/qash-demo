  <div class="tab-content" id="orderTabsContent">
    <div class="tab-pane fade show active" id="all" role="tabpanel">
      <div class="table-responsive">
        <table class="table table-hover align-middle order-table">
          <thead class="table-light">
            <tr>
                <?php echo e($thead); ?>

            </tr>
          </thead>
          <tbody>
            <?php echo e($tbody); ?>

          </tbody>
        </table>
      </div><?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/table.blade.php ENDPATH**/ ?>