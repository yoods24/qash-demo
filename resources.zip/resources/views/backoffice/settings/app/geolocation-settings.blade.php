<x-backoffice.settings-layout>
    <div class="col-md-9">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="mb-3">Geolocation Settings</h5>
                <livewire:backoffice.settings.attendance-settings view="geolocation" />
            </div>
        </div>
    </div>
</x-backoffice.settings-layout>
