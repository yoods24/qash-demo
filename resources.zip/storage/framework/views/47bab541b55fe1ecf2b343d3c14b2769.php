<?php if (isset($component)) { $__componentOriginalef98058bc140d9868c671f00a8b84914 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef98058bc140d9868c671f00a8b84914 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php
      /** @var \Illuminate\Pagination\LengthAwarePaginator|\App\Models\Order[]|null $orders */
      $orders = $orders ?? null;
      $name = $name ?? old('name');
      $email = $email ?? old('email');
  ?>

  <section class="secondary-white">
    <div class="section-wrapper text-black">
      <div class="text-center mb-4">
        <p class="primer bold mb-1">ORDER LOOKUP</p>
        <h2 class="fw-bold mb-2">Check My Orders</h2>
        <p class="text-muted mb-0">Enter your name and email to see your recent orders for this location.</p>
      </div>

      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="card shadow-sm border-0">
            <div class="card-body p-4">
              <form method="POST" action="<?php echo e(route('customer.orders.search')); ?>" class="d-flex flex-column gap-3">
                <?php echo csrf_field(); ?>
                <div>
                  <label class="form-label fw-semibold" for="customer-name">Name</label>
                  <input
                    id="customer-name"
                    type="text"
                    name="name"
                    value="<?php echo e(old('name', $name)); ?>"
                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Enter your name"
                    required
                  >
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                  <label class="form-label fw-semibold" for="customer-email">Email</label>
                  <input
                    id="customer-email"
                    type="email"
                    name="email"
                    value="<?php echo e(old('email', $email)); ?>"
                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="you@example.com"
                    required
                  >
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex justify-content-end">
                  <button type="submit" class="btn btn-main px-4">
                    Check Orders
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <?php if(! is_null($orders)): ?>
        <div class="mt-5">
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0">Results</h5>
            <?php if(method_exists($orders, 'total')): ?>
              <span class="text-muted small">Found <?php echo e($orders->total()); ?> order<?php echo e($orders->total() === 1 ? '' : 's'); ?></span>
            <?php endif; ?>
          </div>

          <?php if($orders->count() > 0): ?>
            <div class="row row-cols-1 row-cols-md-2 g-3">
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                  <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column gap-2">
                      <div class="d-flex justify-content-between align-items-start gap-2">
                        <div>
                          <p class="text-uppercase small text-muted mb-1">Order</p>
                          <h6 class="fw-bold mb-0">#<?php echo e($order->reference_no ?? $order->id); ?></h6>
                        </div>
                        <span class="badge bg-light text-dark text-uppercase"><?php echo e(str_replace('_', ' ', $order->status)); ?></span>
                      </div>
                      <div class="d-flex justify-content-between">
                        <span class="text-muted small">Placed</span>
                        <span class="small fw-semibold"><?php echo e(optional($order->created_at)->format('M d, Y H:i')); ?></span>
                      </div>
                      <div class="d-flex justify-content-between">
                        <span class="text-muted small">Total</span>
                        <span class="small fw-semibold">IDR <?php echo e(number_format((float) $order->grand_total, 0, ',', '.')); ?></span>
                      </div>
                      <div class="mt-auto d-flex justify-content-end">
                        <a href="<?php echo e(route('order.track', $order)); ?>" class="btn btn-outline-main btn-sm px-3">
                          Track Order
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-3">
              <?php echo e($orders->withQueryString()->links()); ?>

            </div>
          <?php else: ?>
            <div class="alert alert-light mt-3 mb-0" role="alert">
              No orders found for this name/email.
            </div>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $attributes = $__attributesOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__attributesOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $component = $__componentOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__componentOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/customer/orders/check.blade.php ENDPATH**/ ?>