<?php if (isset($component)) { $__componentOriginalef98058bc140d9868c671f00a8b84914 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef98058bc140d9868c671f00a8b84914 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php
      /** @var \Illuminate\Support\Collection|\App\Models\Category[] $categories */
      $categories = $categories ?? collect();
  ?>

  <section class="secondary-white">
    <div class="section-wrapper text-black">
      <div class="text-center mb-5">
        <p class="primer bold mb-2">OUR MENU</p>
        <h2 class="fw-bold mb-2">Grid Menu</h2>
        <p class="text-muted mb-0">Browse every section at a glance and find your next favorite dish.</p>
      </div>

      <div class="text-center my-3">
        <a href="<?php echo e(route('customer.order')); ?>">
          <button class="reservation-btn w-50">Order Now</button>
        </a>
      </div>

      <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="menu-grid-section py-5">
          <div class="menu-grid-banner position-relative text-center mb-4 rounded-4 overflow-hidden">
            <div class="position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(135deg, rgba(0,0,0,0.65), rgba(0,0,0,0.4)); z-index: 1;"></div>
            <div class="position-absolute top-0 start-0 w-100 h-100" style="background-image: url('https://picsum.photos/seed/<?php echo e($category->id); ?>/1600/600'); background-size: cover; background-position: center;"></div>
            <div class="position-relative py-5" style="z-index: 2;">
              <p class="text-uppercase text-white mb-1 small" style="letter-spacing: 0.12em;">Section</p>
              <h3 class="fw-bold text-white mb-0"><?php echo e(strtoupper($category->name)); ?></h3>
            </div>
          </div>

          <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php $__empty_2 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
              <div class="col">
                <div class="menu-grid-card h-100 p-3 p-lg-4 bg-white rounded-4 shadow-sm d-flex flex-column gap-2">
                  <div class="d-flex align-items-baseline gap-2">
                    <span class="fw-semibold"><?php echo e($product->name); ?></span>
                    <span class="flex-grow-1 border-bottom" style="border-bottom-style: dashed;"></span>
                    <?php if(! is_null($product->price)): ?>
                      <span class="fw-semibold text-end">
                        <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?>

                      </span>
                    <?php endif; ?>
                  </div>
                  <?php if($product->description): ?>
                    <p class="text-muted small mb-0"><?php echo e($product->description); ?></p>
                  <?php endif; ?>
                  <?php if($product->is_recommended ?? $product->featured ?? false): ?>
                    <div class="mt-auto">
                      <span class="btn btn-outline-dark btn-sm rounded-pill px-3 py-1">
                        ★ Recommend
                      </span>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
              <div class="col">
                <div class="alert alert-light mb-0" role="alert">
                  Items are being prepared for this section. Please check back soon.
                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-light mt-4" role="alert">
          Menu is coming soon. Please check back later.
        </div>
      <?php endif; ?>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $attributes = $__attributesOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__attributesOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $component = $__componentOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__componentOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/customer/menu/grid.blade.php ENDPATH**/ ?>