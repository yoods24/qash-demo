<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.staff-attendance', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1382049038-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
        /** @var \App\Models\User $u */
        $u = auth()->user();
        $shift = $u?->shift;

        $fmtTime = function (?string $t): string {
            if (!$t) return '-';
            try {
                return \Carbon\Carbon::createFromFormat('H:i:s', (string) $t)->format('h:i A');
            } catch (\Throwable $e) {
                return (string) $t;
            }
        };

        $duration = function (?string $start, ?string $end): string {
            if (!$start || !$end) return '-';
            try {
                $s = \Carbon\Carbon::createFromFormat('H:i:s', (string) $start);
                $e = \Carbon\Carbon::createFromFormat('H:i:s', (string) $end);
                if ($e->lessThanOrEqualTo($s)) { $e->addDay(); }
                $sec = $e->diffInSeconds($s);
                $h = intdiv($sec, 3600); $m = intdiv($sec % 3600, 60);
                return sprintf('%02dh %02dm', $h, $m);
            } catch (\Throwable $e) {
                return '';
            }
        };

        $workingDays = function ($shift): string {
            if (!$shift) return '-';
            $dayNames = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun'];
            $off = array_map('intval', (array) ($shift->week_off_days ?? []));
            $list = [];
            for ($d=1; $d<=7; $d++) {
                if (!in_array($d, $off, true)) $list[] = $dayNames[$d];
            }
            return $list ? implode(', ', $list) : 'All days';
        };
    ?>

    <div class="card mt-4">
        <div class="card-body">
            <h6 class="mb-3">Assigned Shift</h6>
            <?php if($shift): ?>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <tbody>
                            <tr>
                                <th style="width: 180px;">Shift Name</th>
                                <td><?php echo e($shift->name); ?></td>
                            </tr>
                            <tr>
                                <th>Working Hours</th>
                                <td><?php echo e($fmtTime($shift->start_time)); ?> - <?php echo e($fmtTime($shift->end_time)); ?> (<?php echo e($duration($shift->start_time, $shift->end_time)); ?>)</td>
                            </tr>
                            <tr>
                                <th>Working Days</th>
                                <td><?php echo e($workingDays($shift)); ?></td>
                            </tr>
                            <?php if(!empty($shift->description)): ?>
                            <tr>
                                <th>Description</th>
                                <td><?php echo e($shift->description); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-muted">No shift assigned to your account yet.</div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/hrm/attendance/index.blade.php ENDPATH**/ ?>