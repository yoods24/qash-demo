<div>
    <?php echo e($this->table); ?>

</div>

<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/livewire/backoffice/tables/career-table.blade.php ENDPATH**/ ?>