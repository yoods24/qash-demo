<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex align-items-center mb-3">
        <i class="bi bi-speedometer2 text-orange fs-3 me-2"></i>
        <h4 class="mb-0">Kitchen Performance</h4>
    </div>

    <form method="get" class="row g-2 align-items-end mb-3">
        <div class="col-md-3">
            <label class="form-label">From</label>
            <input type="date" name="from" class="form-control" value="<?php echo e($from); ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">To</label>
            <input type="date" name="to" class="form-control" value="<?php echo e($to); ?>">
        </div>
        <div class="col-md-3">
            <button class="btn btn-primary">Apply</button>
        </div>
    </form>

    <div class="row g-3 mb-4">
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Completed</div>
                <div class="fs-4 fw-bold"><?php echo e($summary['totalCompleted']); ?></div>
            </div></div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">On Time</div>
                <div class="fs-4 fw-bold text-success"><?php echo e($summary['onTime']); ?></div>
            </div></div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Late (Warning)</div>
                <div class="fs-4 fw-bold text-warning"><?php echo e($summary['lateWarn']); ?></div>
            </div></div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Late (Danger)</div>
                <div class="fs-4 fw-bold text-danger"><?php echo e($summary['lateDanger']); ?></div>
            </div></div>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body d-flex align-items-center justify-content-between">
            <div>
                <div class="text-muted">Monthly Rating (avg of daily)</div>
                <div class="fs-3 fw-bold"><?php echo e(number_format($summary['monthlyRating'], 2)); ?> / 5.00</div>
            </div>
            <div class="fs-4">
                <?php
                    $r = (float) $summary['monthlyRating'];
                    $full = floor($r);
                    $half = ($r - $full) >= 0.5 ? 1 : 0;
                    $empty = 5 - $full - $half;
                ?>
                <?php for($i=0;$i<$full;$i++): ?> <i class="bi bi-star-fill text-warning"></i> <?php endfor; ?>
                <?php if($half): ?> <i class="bi bi-star-half text-warning"></i> <?php endif; ?>
                <?php for($i=0;$i<$empty;$i++): ?> <i class="bi bi-star text-warning"></i> <?php endfor; ?>
            </div>
        </div>
    </div>

    

    <div class="card shadow-sm">
        <div class="card-header fw-semibold">Daily Ratings</div>
        <div class="card-body">
            <?php if(empty($dailyRatings)): ?>
                <div class="text-muted">No data.</div>
            <?php else: ?>
                <ul class="mb-0">
                <?php $__currentLoopData = $dailyRatings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($d['day']); ?> — <?php echo e(number_format($d['score'], 2)); ?>/5</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/reports/kitchen-performance.blade.php ENDPATH**/ ?>