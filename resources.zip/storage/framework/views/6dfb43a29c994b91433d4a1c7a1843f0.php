<?php if (isset($component)) { $__componentOriginalef98058bc140d9868c671f00a8b84914 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef98058bc140d9868c671f00a8b84914 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('payment-page', ['order' => $order]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1849591750-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $attributes = $__attributesOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__attributesOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $component = $__componentOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__componentOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/payment/payment-page.blade.php ENDPATH**/ ?>