<x-backoffice.settings-layout>
    <p>test</p>
</x-backoffice.settings-layout>
