
<div class="section-title"><?php echo e($attributes->get('section')); ?></div>
    <ul class="nav nav-pills flex-column mb-3">
        <?php echo e($slot); ?>

</ul>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/sidebar-nav-section.blade.php ENDPATH**/ ?>