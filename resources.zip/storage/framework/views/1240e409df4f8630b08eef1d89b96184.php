<footer>
    <div class="bg-black d-flex justify-content-around p-5 text-white flex-wrap gap-4">

        <!-- Contact Section -->
        <div>
            <h4>CONTACT</h4>
            <p><i class="fas fa-envelope me-2"></i> test@example.com</p>
            <p><i class="fas fa-phone me-2"></i> 000-000-000</p>
            <p><i class="fas fa-map-marker-alt me-2"></i> 890 Lorem Ipsum</p>
        </div>

        <!-- About Section -->
        <div class="text-center">
            <h4>ABOUT</h4>
            <p style="opacity: 0.7">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut, tempore.
            </p>
        </div>

        <!-- Quick Links Section -->
        <div>
            <h4>QUICK LINKS</h4>
            <ul class="list-unstyled">
                <li><a href="#" class="text-white text-decoration-none">Lorem Link 1</a></li>
                <li><a href="#" class="text-white text-decoration-none">Lorem Link 2</a></li>
                <li><a href="#" class="text-white text-decoration-none">Lorem Link 3</a></li>
            </ul>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/customer/footer.blade.php ENDPATH**/ ?>