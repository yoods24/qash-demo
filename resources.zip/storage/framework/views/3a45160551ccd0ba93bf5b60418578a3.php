<?php if (isset($component)) { $__componentOriginal04028366e911435fb447a8c3d2d17713 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04028366e911435fb447a8c3d2d17713 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.settings-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.settings-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="col-md-9">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="mb-3">Geolocation Settings</h5>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.settings.attendance-settings', ['view' => 'geolocation']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1421506745-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $attributes = $__attributesOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__attributesOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $component = $__componentOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__componentOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/settings/app/geolocation-settings.blade.php ENDPATH**/ ?>