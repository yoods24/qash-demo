<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-3">
        <h5 class="mb-1">QR Code for <?php echo e($table->label); ?></h5>
        <div class="text-muted small">Tenant: <?php echo e($tenantId); ?></div>
        <?php if(session('status')): ?>
            <div class="alert alert-success py-1 my-2"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <div class="small">Scan URL: <a href="<?php echo e($scanUrl); ?>" target="_blank"><?php echo e($scanUrl); ?></a></div>
        <div class="small mt-1">Current code: <code><?php echo e($table->qr_code ?? '— none —'); ?></code></div>
    </div>

    <div class="card">
        <div class="card-body d-flex justify-content-center">
            <div id="qrcode"></div>
        </div>
    </div>

    <div class="mt-3 d-flex gap-2 align-items-center">
        <form action="<?php echo e(route('backoffice.tables.qr.generate', ['tenant' => $tenantId, 'dining_table' => $table->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Generate a new code</button>
        </form>
        <button id="printBtn" class="btn btn-outline-secondary">Print</button>
        <a href="<?php echo e(route('backoffice.tables.info', ['tenant' => $tenantId])); ?>" class="btn btn-secondary">Back</a>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function(){
            const url = <?php echo json_encode($scanUrl, 15, 512) ?>;
            const el = document.getElementById('qrcode');
            // Generate QR
            new QRCode(el, { text: url, width: 256, height: 256, correctLevel: QRCode.CorrectLevel.M });
            // Print helper
            document.getElementById('printBtn').addEventListener('click', () => window.print());
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/tables/qr.blade.php ENDPATH**/ ?>