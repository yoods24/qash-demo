<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 mb-md-4 flex-wrap gap-2">
        <div class="d-flex align-items-center">
            <i class="bi bi-images text-orange fs-3 me-2"></i>
            <h4 class="mb-0">Gallery</h4>
        </div>
        <div class="text-muted small">Maximum 5 photos</div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('backoffice.gallery.store')); ?>" enctype="multipart/form-data" class="row g-3">
                <?php echo csrf_field(); ?>
                <div class="col-12 col-md-8">
                    <label class="form-label fw-semibold">Upload photos</label>
                    <input
                        type="file"
                        name="photos[]"
                        accept="image/*"
                        multiple
                        class="form-control <?php $__errorArgs = ['photos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        <?php echo e(count($photos) >= 5 ? 'disabled' : ''); ?>

                    >
                    <?php $__errorArgs = ['photos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text">You can upload up to <?php echo e(max(0, 5 - count($photos))); ?> more photo(s).</div>
                </div>
                <div class="col-12 col-sm-12">
                    <button class="btn btn-primer 100" <?php echo e(count($photos) >= 5 ? 'disabled' : ''); ?>>
                        <i class="bi bi-upload me-1"></i> Add Photos
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3">
        <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="card border-0 shadow-sm h-100 rounded-4 overflow-hidden">
                    <div class="ratio ratio-4x3">
                        <img src="<?php echo e(tenant_storage_url($photo)); ?>" class="w-100 h-100 object-fit-cover" alt="Gallery photo">
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <span class="text-truncate small"><?php echo e($photo); ?></span>
                        <form method="POST" action="<?php echo e(route('backoffice.gallery.destroy')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="photo" value="<?php echo e($photo); ?>">
                            <button type="submit" class="btn btn-outline-danger btn-sm" onclick="return confirm('Remove this photo?')">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-light mb-0">No photos yet. Upload up to 5 images to show in your customer gallery.</div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/cms/gallery.blade.php ENDPATH**/ ?>