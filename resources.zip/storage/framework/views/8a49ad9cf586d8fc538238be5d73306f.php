<?php
    $resolveOptions = function ($item): array {
        $raw = data_get(
            $item,
            'product_options',
            data_get($item, 'options.options', data_get($item, 'options', []))
        );
        $excludedKeys = ['category', 'description', 'estimated_seconds', 'base_price', 'note'];

        if ($raw instanceof \Illuminate\Support\Collection) {
            $raw = $raw->toArray();
        }

        if (is_array($raw) && array_key_exists('options', $raw) && is_array($raw['options'])) {
            $raw = $raw['options'];
        }

        if (! is_array($raw)) {
            return [];
        }

        $lines = [];

        foreach ($raw as $key => $option) {
            $label = is_string($key) ? $key : null;
            $keyLabel = $label ? strtolower($label) : null;

            if ($keyLabel && in_array($keyLabel, $excludedKeys, true)) {
                continue;
            }

            if (! is_array($option)) {
                $valueText = (string) $option;
                if ($valueText === '') {
                    continue;
                }

                $lines[] = [
                    'label' => $label ?? __('Option'),
                    'value' => $valueText,
                    'adjustment' => 0,
                    'price_adjustment' => 0,
                ];

                continue;
            }

            if (isset($option['option_value']) && is_array($option['option_value'])) {
                $lineLabel = $option['label'] ?? $option['name'] ?? $option['title'] ?? $label ?? __('Option');
                $value = $option['option_value']['value'] ?? $option['option_value']['name'] ?? '';
                $adjustmentValue = (int) ($option['option_value']['price_adjustment'] ?? $option['option_value']['adjustment'] ?? 0);

                if ($value === '' || in_array(strtolower((string) $lineLabel), $excludedKeys, true)) {
                    continue;
                }

                $lines[] = [
                    'label' => $lineLabel,
                    'value' => $value,
                    'adjustment' => $adjustmentValue,
                    'price_adjustment' => $adjustmentValue,
                ];

                continue;
            }

            $lineLabel = $option['label'] ?? $option['name'] ?? $option['title'] ?? $option['option'] ?? $option['display_name'] ?? $label ?? __('Option');
            $value = $option['value'] ?? $option['values'] ?? $option['selection'] ?? $option['selected'] ?? $option['options'] ?? $option;

            $value = collect(\Illuminate\Support\Arr::wrap($value))
                ->flatMap(function ($itemValue) {
                    if (is_array($itemValue)) {
                        if (isset($itemValue['value'])) {
                            return [$itemValue['value']];
                        }

                        if (isset($itemValue['name'])) {
                            return [$itemValue['name']];
                        }

                        return collect($itemValue)
                            ->filter(fn ($nestedValue) => is_scalar($nestedValue))
                            ->values();
                    }

                    return [$itemValue];
                })
                ->filter(fn ($text) => $text !== null && $text !== '')
                ->implode(', ');

            if ($value === '') {
                continue;
            }

            if (in_array(strtolower((string) $lineLabel), $excludedKeys, true)) {
                continue;
            }

            $adjustmentValue = (int) ($option['price_adjustment'] ?? $option['adjustment'] ?? 0);

            $lines[] = [
                'label' => $lineLabel,
                'value' => $value,
                'adjustment' => $adjustmentValue,
                'price_adjustment' => $adjustmentValue,
            ];
        }

        return $lines;
    };

    $incomingTotals = isset($totals) && is_array($totals) ? $totals : [];
    $taxLines = $order->taxLines ?? collect();
    if (! $taxLines instanceof \Illuminate\Support\Collection) {
        $taxLines = collect($taxLines);
    }
    $items = $order->items ?? collect();
    if (! $items instanceof \Illuminate\Support\Collection) {
        $items = collect($items);
    }
    $itemsSubtotal = (float) $items->sum(fn ($item) => ((float) ($item->unit_price ?? $item->price ?? 0)) * (int) ($item->quantity ?? 1));
    $itemsDiscount = (float) $items->sum(fn ($item) => ((float) ($item->discount_amount ?? 0)) * (int) ($item->quantity ?? 1));
    $itemsFinal = (float) $items->sum(fn ($item) => ((float) ($item->final_price ?? $item->unit_price ?? $item->price ?? 0)) * (int) ($item->quantity ?? 1));
    $subtotal = (float) ($incomingTotals['subtotal'] ?? ($order->subtotal ?? $order->total ?? 0));
    $preDiscountSubtotal = $itemsSubtotal > 0 ? $itemsSubtotal : $subtotal;
    $discountTotal = $itemsDiscount > 0 ? $itemsDiscount : max($preDiscountSubtotal - $subtotal, 0);
    $subtotalAfterDiscount = max($preDiscountSubtotal - $discountTotal, 0);
    $subtotal = $subtotalAfterDiscount;
    $totalTax = (float) ($incomingTotals['total_tax'] ?? ($order->total_tax ?? $taxLines->sum('amount')));
    $grandTotal = (float) ($incomingTotals['grand_total'] ?? ($order->grand_total ?? $order->total ?? ($subtotal + $totalTax)));
    $xenditFee = (float) ($incomingTotals['xendit_fee'] ?? ($order->xendit_fee ?? 0));
    $qashFee = (float) ($incomingTotals['qash_fee'] ?? ($order->qash_fee ?? 0));
    $feesTotal = (float) ($incomingTotals['fees_total'] ?? ($xenditFee + $qashFee));
    $netReceived = (float) ($incomingTotals['net'] ?? ($grandTotal - $feesTotal));
    $discountNameFor = function ($item) {
        return optional($item->discount)->name;
    };
?>

<div class="mt-4">
    <h5 class="fw-semibold mb-3">Items</h5>
    <div class="table-responsive border rounded-4">
        <table class="table align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="fw-semibold text-uppercase small text-muted ps-4">Product</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $unitPrice = (float) ($item->unit_price ?? $item->price ?? 0);
                        $quantity = (int) ($item->quantity ?? 1);
                        $lineOriginal = $unitPrice * $quantity;
                        $lineFinal = (float) ($item->final_price ?? $item->unit_price ?? $item->price ?? 0) * $quantity;
                        $lineDiscount = (float) ($item->discount_amount ?? 0) * $quantity;
                        $optionLines = $resolveOptions($item);
                        $itemName = $item->product_name ?? $item->name ?? __('Item');
                        $discountLabel = $discountNameFor($item);
                    ?>
                    <tr>
                        <td class="ps-4 py-4" colspan="2">
                            <div class="d-flex justify-content-between align-items-start gap-3">
                                <div>
                                    <div class="fw-semibold"><?php echo e($itemName); ?></div>
                                    <div class="text-muted small">Qty: <?php echo e($quantity); ?></div>
                                </div>
                                <div class="text-end">
                                    <div class="text-muted small <?php echo e($lineDiscount > 0 ? 'text-decoration-line-through' : ''); ?>">
                                        Item price: <?php echo e(rupiah($lineOriginal)); ?>

                                    </div>
                                    <?php if($lineDiscount > 0): ?>
                                        <div class="text-success small">
                                            Discount (<?php echo e($discountLabel ?? 'Promo'); ?>): -<?php echo e(rupiah($lineDiscount)); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div class="fw-semibold"><?php echo e(rupiah($lineFinal)); ?></div>
                                </div>
                            </div>
                            <?php if(! empty($optionLines)): ?>
                                <div class="text-muted small mt-2">
                                    <?php $__currentLoopData = $optionLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <span class="fw-semibold"><?php echo e($line['label']); ?></span>: <?php echo e($line['value']); ?>

                                            <?php $adjustment = $line['adjustment'] ?? 0; ?>
                                            <?php if($adjustment > 0): ?>
                                                (+ <?php echo e(rupiah($adjustment)); ?>)
                                            <?php elseif($adjustment < 0): ?>
                                                (– <?php echo e(rupiah(abs($adjustment))); ?>)
                                            <?php else: ?>
                                                (None)
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4 border-top pt-3">
        <div class="d-flex justify-content-between py-1">
            <span class="text-muted">Subtotal</span>
            <span class="fw-semibold"><?php echo e(rupiah($preDiscountSubtotal)); ?></span>
        </div>
        <div class="d-flex justify-content-between py-1">
            <span class="text-muted">Discount</span>
            <span class="text-success">- <?php echo e(rupiah($discountTotal)); ?></span>
        </div>
        <div class="d-flex justify-content-between py-1">
            <span class="text-muted">Subtotal after discount</span>
            <span class="fw-semibold"><?php echo e(rupiah($subtotalAfterDiscount)); ?></span>
        </div>

        <?php $__currentLoopData = $taxLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-between py-1">
                <span class="text-muted">
                    <?php echo e($taxLine->name ?? $taxLine['name'] ?? 'Tax'); ?>

                    <?php
                        $type = $taxLine->type ?? $taxLine['type'] ?? null;
                        $rate = $taxLine->rate ?? $taxLine['rate'] ?? null;
                    ?>
                    <?php if($type === 'percentage' && $rate !== null): ?>
                        (<?php echo e(rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.')); ?>%)
                    <?php endif; ?>
                </span>
                <span><?php echo e(rupiah($taxLine->amount ?? $taxLine['amount'] ?? 0)); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex justify-content-between py-1">
            <span class="text-muted">Total Tax</span>
            <span><?php echo e(rupiah($totalTax)); ?></span>
        </div>

        <div class="d-flex justify-content-between py-1 border-top mt-2 pt-2">
            <span class="fw-semibold">Total (incl. tax)</span>
            <span class="fw-bold" style="color: #f58220;"><?php echo e(rupiah($grandTotal)); ?></span>
        </div>

        <div class="d-flex justify-content-between py-1 mt-3">
            <span class="text-muted">Xendit Fee</span>
            <span><?php echo e(rupiah($xenditFee)); ?></span>
        </div>
        <div class="d-flex justify-content-between py-1">
            <span class="text-muted">Platform Fee</span>
            <span><?php echo e(rupiah($qashFee)); ?></span>
        </div>
        <div class="d-flex justify-content-between py-1 border-top mt-2 pt-2">
            <span class="fw-semibold">Net Received</span>
            <span class="fw-bold"><?php echo e(rupiah($netReceived)); ?></span>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/payment/partials/order-items-table.blade.php ENDPATH**/ ?>