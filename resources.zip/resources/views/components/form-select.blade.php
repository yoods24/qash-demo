<div class="mb-3">
    <label for="delivery_method" class="form-label">Delivery Method</label>
    <select class="form-select" id="delivery_method" name="delivery_method" required>
        <option value="Free Shipping">Free Shipping</option>
        <option value="Express Shipping">Express Shipping</option>
    </select>
</div>