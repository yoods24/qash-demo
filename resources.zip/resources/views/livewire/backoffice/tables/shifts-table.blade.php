<div id="fi-app">
    {{ $this->table }}
    
    {{-- If you add other Filament widgets on this page, keep them within this container
         so Tailwind utilities (prefixed `tw-`) stay scoped and don’t leak into Bootstrap UI. --}}
</div>
