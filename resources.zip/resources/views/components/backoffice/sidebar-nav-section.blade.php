
<div class="section-title">{{$attributes->get('section')}}</div>
    <ul class="nav nav-pills flex-column mb-3">
        {{$slot}}
</ul>
