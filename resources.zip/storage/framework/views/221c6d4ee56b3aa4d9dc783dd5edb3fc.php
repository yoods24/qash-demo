<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $map = [
        'entertainment' => ['label' => 'Entertainment', 'icon' => 'bi-music-note-beamed', 'class' => 'event-type-badge--entertainment'],
        'announcement' => ['label' => 'Announcement', 'icon' => 'bi-megaphone', 'class' => 'event-type-badge--announcement'],
        'promotions' => ['label' => 'Promotions', 'icon' => 'bi-lightning-charge', 'class' => 'event-type-badge--promotions'],
        'special_event' => ['label' => 'Special Event', 'icon' => 'bi-stars', 'class' => 'event-type-badge--special-event'],
        'workshop' => ['label' => 'Workshop', 'icon' => 'bi-tools', 'class' => 'event-type-badge--workshop'],
        'community' => ['label' => 'Community', 'icon' => 'bi-people', 'class' => 'event-type-badge--community'],
        'operational' => ['label' => 'Operational', 'icon' => 'bi-gear', 'class' => 'event-type-badge--operational'],
    ];
    $meta = $map[$type] ?? ['label' => ucfirst(str_replace('_', ' ', $type ?? 'Event')), 'icon' => 'bi-calendar-event', 'class' => ''];
?>
<span class="event-type-badge <?php echo e($meta['class']); ?>">
    <i class="bi <?php echo e($meta['icon']); ?>"></i>
    <span><?php echo e($meta['label']); ?></span>
</span>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/event-type-badge.blade.php ENDPATH**/ ?>