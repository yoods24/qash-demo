<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 mb-md-4 flex-wrap gap-2">
        <div class="d-flex align-items-center">
            <i class="bi bi-cash text-orange fs-3 me-2"></i>
            <h4 class="mb-0">Sales Report</h4>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('backoffice.reports.sales', request()->route()->parameters())); ?>" class="row g-2 g-md-3 align-items-end">
                <div class="col-12 col-md-3">
                    <label class="form-label">Start date</label>
                    <input type="date" name="start_date" value="<?php echo e($startDate->toDateString()); ?>" class="form-control" />
                </div>
                <div class="col-12 col-md-3">
                    <label class="form-label">End date</label>
                    <input type="date" name="end_date" value="<?php echo e($endDate->toDateString()); ?>" class="form-control" />
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label">Granularity</label>
                    <select name="granularity" class="form-select">
                        <?php $__currentLoopData = ['daily' => 'Daily', 'monthly' => 'Monthly']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($granularity === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Successful</option>
                        <?php $__currentLoopData = ['confirmed','preparing','ready','cancelled','waiting_for_payment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_',' ', $s))); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-1 col-sm-12 col-md-12 text-center">
                    <button class="btn btn-main w-100"><i class="bi bi-funnel me-1"></i></button>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <?php
            $summaryCards = [
                ['label' => 'Gross Sales', 'value' => $totalSalesBeforeDiscount],
                ['label' => 'Discounts', 'value' => $totalDiscount],
                ['label' => 'Net Sales', 'value' => $netSales],
                ['label' => 'Tax', 'value' => $totalTax],
                ['label' => 'COGS', 'value' => $totalCogs],
                ['label' => 'Gross Profit', 'value' => $grossProfit],
            ];
        ?>
        <?php $__currentLoopData = $summaryCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-4 col-xl-2">
                <div class="card border-0 shadow-sm h-100 rounded-4">
                    <div class="card-body">
                        <p class="text-primer mb-1 small text-uppercase"><?php echo e($card['label']); ?></p>
                        <h5 class="mb-0 fw-bold">IDR <?php echo e(number_format((float) $card['value'], 0, ',', '.')); ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sales-chart-widget', [
                'startDate' => $startDate->toDateString(),
                'endDate' => $endDate->toDateString(),
                'granularity' => $granularity,
            ]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2009978868-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="text-muted">Order</th>
                            <th class="text-muted">Date</th>
                            <th class="text-muted">Customer</th>
                            <th class="text-muted">Status</th>
                            <th class="text-muted">Net</th>
                            <th class="text-muted">Tax</th>
                            <th class="text-muted">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($order->reference_no ?? $order->id); ?></td>
                                <td><?php echo e(optional($order->created_at)->format('M d, Y H:i')); ?></td>
                                <td><?php echo e($order->customerDetail->name ?? 'Guest'); ?></td>
                                <td><span class="badge bg-light text-dark text-uppercase"><?php echo e(str_replace('_',' ', $order->status)); ?></span></td>
                                <td>IDR <?php echo e(number_format((float) (($order->grand_total ?? 0) - ($order->total_tax ?? 0)), 0, ',', '.')); ?></td>
                                <td>IDR <?php echo e(number_format((float) $order->total_tax, 0, ',', '.')); ?></td>
                                <td>IDR <?php echo e(number_format((float) $order->grand_total, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">No orders for the selected period.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($orders instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
            <div class="card-footer bg-white border-0">
                <?php echo e($orders->withQueryString()->links()); ?>

            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/reports/sales.blade.php ENDPATH**/ ?>