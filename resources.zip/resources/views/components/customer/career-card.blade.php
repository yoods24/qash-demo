<div class="d-flex flex-column job-card">
        <img class="job-card-img mb-3" src="http://picsum.photos/seed/{{rand(0, 10000)}}/600/600" alt="img">
        <p class="">By Yuda</p>
        <h5>Junior Waiter at The Kitchen</h5>
        <div class="text-muted ">
            <a class="text-decoration-none text-muted read-more-link" href="">READ MORE</a>
            <span>></span>
        </div>
</div>