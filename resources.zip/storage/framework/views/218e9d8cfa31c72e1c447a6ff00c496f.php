<?php if (isset($component)) { $__componentOriginal04028366e911435fb447a8c3d2d17713 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04028366e911435fb447a8c3d2d17713 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.settings-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.settings-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $profile = $tenantProfile ?? new \App\Models\TenantProfile();
        $daysOfWeek = [
            'monday' => 'Monday',
            'tuesday' => 'Tuesday',
            'wednesday' => 'Wednesday',
            'thursday' => 'Thursday',
            'friday' => 'Friday',
            'saturday' => 'Saturday',
            'sunday' => 'Sunday',
        ];
        $socialPlatforms = [
            'instagram' => 'Instagram',
            'tiktok' => 'TikTok',
            'whatsapp' => 'WhatsApp',
            'facebook' => 'Facebook',
            'website' => 'Website',
        ];
    ?>

    <div class="col-md-9">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div>
                        <h5 class="mb-1">Company Information</h5>
                        <p class="text-muted mb-0">Update the brand details that your customers will see.</p>
                    </div>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <div class="fw-semibold mb-1">Please fix the following issues:</div>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('backoffice.tenant-profile.update-general-info')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="contact_email">Contact Email</label>
                            <input
                                type="email"
                                class="form-control"
                                id="contact_email"
                                name="contact_email"
                                value="<?php echo e(old('contact_email', $profile->contact_email ?? '')); ?>"
                                placeholder="hello@brand.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="contact_phone">Contact Phone</label>
                            <input
                                type="text"
                                class="form-control"
                                id="contact_phone"
                                name="contact_phone"
                                value="<?php echo e(old('contact_phone', $profile->contact_phone ?? '')); ?>"
                                placeholder="+62 812 1234 5678">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold" for="address">Address</label>
                            <textarea
                                class="form-control"
                                id="address"
                                name="address"
                                rows="3"
                                placeholder="Jl. Example No. 1, Jakarta"><?php echo e(old('address', $profile->address ?? '')); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="latitude">Latitude</label>
                            <input
                                type="number"
                                step="any"
                                class="form-control"
                                id="latitude"
                                name="latitude"
                                value="<?php echo e(old('latitude', $profile->latitude)); ?>"
                                placeholder="-6.2088">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="longitude">Longitude</label>
                            <input
                                type="number"
                                step="any"
                                class="form-control"
                                id="longitude"
                                name="longitude"
                                value="<?php echo e(old('longitude', $profile->longitude)); ?>"
                                placeholder="106.8456">
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Opening Hours</label>
                            <div class="row g-2">
                                <?php $__currentLoopData = $daysOfWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-text fw-semibold" style="min-width: 130px;"><?php echo e($label); ?></span>
                                            <input
                                                type="text"
                                                class="form-control"
                                                name="opening_hours[<?php echo e($key); ?>]"
                                                value="<?php echo e(old('opening_hours.' . $key, data_get($profile->opening_hours, $key, ''))); ?>"
                                                placeholder="08:00 - 21:00">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <small class="text-muted">Leave blank for closed days.</small>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Social Links</label>
                            <div class="row g-2">
                                <?php $__currentLoopData = $socialPlatforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platformKey => $platformLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <label class="form-label small text-muted" for="social_<?php echo e($platformKey); ?>"><?php echo e($platformLabel); ?></label>
                                        <input
                                            type="url"
                                            class="form-control"
                                            id="social_<?php echo e($platformKey); ?>"
                                            name="social_links[<?php echo e($platformKey); ?>]"
                                            value="<?php echo e(old('social_links.' . $platformKey, data_get($profile->social_links, $platformKey, ''))); ?>"
                                            placeholder="https://<?php echo e($platformKey); ?>.com/yourbrand">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold" for="logo_url">Logo URL</label>
                            <input
                                type="url"
                                class="form-control"
                                id="logo_url"
                                name="logo_url"
                                value="<?php echo e(old('logo_url', $profile->logo_url ?? '')); ?>"
                                placeholder="https://cdn.brand.com/logo.png">
                            <small class="text-muted">Use a hosted image link for now.</small>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button type="submit" class="btn btn-main px-4">
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $attributes = $__attributesOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__attributesOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $component = $__componentOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__componentOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/settings/general-information/company-information-settings.blade.php ENDPATH**/ ?>