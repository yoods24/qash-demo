<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['career']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['career']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $aboutPreview = \Illuminate\Support\Str::limit(strip_tags($career->about), 180);
?>

<div class="col-12 mb-4">
  <div class="career-card text-black bg-white rounded-4 shadow-sm p-4 p-md-5">
    <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
      <div class="flex-grow-1">
        <h4 class="mb-1"><?php echo e($career->title); ?></h4>
        <div class="d-flex flex-wrap gap-3 align-items-center small text-muted mb-2">
          <span><i class="bi bi-briefcase-fill primer me-1"></i> Cafe Operations</span>
          <span><i class="bi bi-geo-alt-fill primer me-1"></i> Downtown Location</span>
          <span><i class="bi bi-clock-fill primer me-1"></i> Full-time</span>
        </div>
        <?php if($career->salary_range): ?>
          <div class="fw-semibold primer mb-2"><?php echo e($career->salary_range); ?> / month</div>
        <?php endif; ?>
        <p class="mb-0 text-secondary"><?php echo e($aboutPreview); ?></p>
      </div>
      <div class="mt-3 mt-md-0">
        <a href="<?php echo e(route('customer.career.show', ['tenant' => request()->route('tenant'), 'career' => $career])); ?>" class="btn btn-main px-4">
          Apply Now
        </a>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/customer/career-card-wide.blade.php ENDPATH**/ ?>