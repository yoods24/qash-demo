<?php if (isset($component)) { $__componentOriginalef98058bc140d9868c671f00a8b84914 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef98058bc140d9868c671f00a8b84914 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $taxLines = $order->taxLines ?? collect();
        if (! $taxLines instanceof \Illuminate\Support\Collection) {
            $taxLines = collect($taxLines);
        }
        $totals = [
            'subtotal' => (float) ($order->subtotal ?? $order->total ?? 0),
            'total_tax' => (float) ($order->total_tax ?? $taxLines->sum('amount')),
            'grand_total' => (float) ($order->grand_total ?? $order->total ?? 0),
            'xendit_fee' => (float) ($order->xendit_fee ?? 0),
            'qash_fee' => (float) ($order->qash_fee ?? 0),
        ];
        $items = $order->items ?? collect();
        if (! $items instanceof \Illuminate\Support\Collection) {
            $items = collect($items);
        }
        $itemsSubtotal = (float) $items->sum(fn ($item) => ((float) ($item->unit_price ?? $item->price ?? 0)) * (int) ($item->quantity ?? 1));
        $itemsDiscount = (float) $items->sum(fn ($item) => ((float) ($item->discount_amount ?? 0)) * (int) ($item->quantity ?? 1));
        $totals['pre_discount_subtotal'] = $itemsSubtotal > 0 ? $itemsSubtotal : $totals['subtotal'];
        $totals['discount_total'] = $itemsDiscount > 0 ? $itemsDiscount : max($totals['pre_discount_subtotal'] - $totals['subtotal'], 0);
        $totals['subtotal_after_discount'] = max($totals['pre_discount_subtotal'] - $totals['discount_total'], 0);
        $totals['subtotal'] = $totals['subtotal_after_discount'];
        $totals['fees_total'] = $totals['xendit_fee'] + $totals['qash_fee'];
        $totals['net'] = $totals['grand_total'] - $totals['fees_total'];
        $discountNameFor = function ($item) {
            return optional($item->discount)->name;
        };
        $resolveOptions = function ($item): array {
            $raw = data_get(
                $item,
                'product_options',
                data_get($item, 'options.options', data_get($item, 'options', []))
            );
            $excludedKeys = ['category', 'description', 'estimated_seconds', 'base_price', 'note'];

            if ($raw instanceof \Illuminate\Support\Collection) {
                $raw = $raw->toArray();
            }

            if (is_array($raw) && array_key_exists('options', $raw) && is_array($raw['options'])) {
                $raw = $raw['options'];
            }

            if (! is_array($raw)) {
                return [];
            }

            $lines = [];

            foreach ($raw as $key => $option) {
                $label = is_string($key) ? $key : null;
                $keyLabel = $label ? strtolower($label) : null;

                if ($keyLabel && in_array($keyLabel, $excludedKeys, true)) {
                    continue;
                }

                if (! is_array($option)) {
                    $valueText = (string) $option;
                    if ($valueText === '') {
                        continue;
                    }

                    $lines[] = [
                        'label' => $label ?? __('Option'),
                        'value' => $valueText,
                        'adjustment' => 0,
                    ];

                    continue;
                }

                if (isset($option['option_value']) && is_array($option['option_value'])) {
                    $lineLabel = $option['label'] ?? $option['name'] ?? $option['title'] ?? $label ?? __('Option');
                    $value = $option['option_value']['value'] ?? $option['option_value']['name'] ?? '';
                    $adjustmentValue = (int) ($option['option_value']['price_adjustment'] ?? $option['option_value']['adjustment'] ?? 0);

                    if ($value === '' || in_array(strtolower((string) $lineLabel), $excludedKeys, true)) {
                        continue;
                    }

                    $lines[] = [
                        'label' => $lineLabel,
                        'value' => $value,
                        'adjustment' => $adjustmentValue,
                    ];

                    continue;
                }

                $lineLabel = $option['label'] ?? $option['name'] ?? $option['title'] ?? $option['option'] ?? $option['display_name'] ?? $label ?? __('Option');
                $value = $option['value'] ?? $option['values'] ?? $option['selection'] ?? $option['selected'] ?? $option['options'] ?? $option;

                $value = collect(\Illuminate\Support\Arr::wrap($value))
                    ->flatMap(function ($itemValue) {
                        if (is_array($itemValue)) {
                            if (isset($itemValue['value'])) {
                                return [$itemValue['value']];
                            }

                            if (isset($itemValue['name'])) {
                                return [$itemValue['name']];
                            }

                            return collect($itemValue)
                                ->filter(fn ($nestedValue) => is_scalar($nestedValue))
                                ->values();
                        }

                        return [$itemValue];
                    })
                    ->filter(fn ($text) => $text !== null && $text !== '')
                    ->implode(', ');

                if ($value === '') {
                    continue;
                }

                if (in_array(strtolower((string) $lineLabel), $excludedKeys, true)) {
                    continue;
                }

                $adjustmentValue = (int) ($option['price_adjustment'] ?? $option['adjustment'] ?? 0);

                $lines[] = [
                    'label' => $lineLabel,
                    'value' => $value,
                    'adjustment' => $adjustmentValue,
                ];
            }

            return $lines;
        };
        $status = strtolower((string) ($order->status ?? 'confirmed'));
        $labels = ['confirmed' => 'Confirmed', 'preparing' => 'Preparing', 'ready' => 'Ready'];
        $steps = [
            'confirmed' => in_array($status, ['confirmed', 'preparing', 'ready', 'completed'], true),
            'preparing' => in_array($status, ['preparing', 'ready', 'completed'], true),
            'ready' => in_array($status, ['ready', 'completed'], true),
        ];
        $currentLabel = $labels[$status] ?? ucfirst($status);
    ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('customer.order-tracker-header', ['order' => $order]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2307765277-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <style>
        .order-tracking-wrapper .order-tracking-card {
            border-radius: 32px;
        }
        .order-tracking-item {
            gap: 1.25rem;
        }
        .order-tracking-total-line {
            gap: .5rem;
        }
        .order-tracking-actions .btn {
            min-height: 56px;
        }
        @media (max-width: 991.98px) {
            .order-tracking-wrapper .order-tracking-card {
                padding: 1.75rem !important;
            }
        }
        @media (max-width: 767.98px) {
            .order-tracking-wrapper {
                padding-left: 1rem;
                padding-right: 1rem;
            }
            .order-tracking-wrapper .order-tracking-card {
                padding: 1.5rem !important;
            }
            .order-tracking-item {
                flex-direction: column;
                align-items: flex-start !important;
            }
            .order-tracking-total-line {
                flex-direction: column;
                align-items: flex-start !important;
            }
            .order-tracking-actions {
                flex-direction: column !important;
            }
        }
        @media (max-width: 575.98px) {
            .order-tracking-wrapper {
                padding-left: .5rem;
                padding-right: .5rem;
            }
            .order-tracking-wrapper .order-tracking-card {
                border-radius: 22px;
            }
            .order-tracking-actions .btn {
                width: 100%;
            }
        }
    </style>

    <div class="container text-black order-tracking-wrapper">
        <div class="rounded-5 border border-light-subtle shadow-sm p-4 p-md-5 mt-4 order-tracking-card">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <div>
                    <h4 class="fw-bold mb-1">Items</h4>
                    <p class="text-muted mb-0">Review everything included in this order.</p>
                </div>
            </div>

            <div class="bg-light rounded-4 px-4 py-2 fw-semibold text-uppercase small text-muted mb-3">
                Product
            </div>

            <div class="pb-3">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $unitPrice = (float) ($item->unit_price ?? $item->price ?? 0);
                        $quantity = (int) ($item->quantity ?? 1);
                        $lineOriginal = $unitPrice * $quantity;
                        $lineFinal = (float) ($item->final_price ?? $item->unit_price ?? $item->price ?? 0) * $quantity;
                        $lineDiscount = (float) ($item->discount_amount ?? 0) * $quantity;
                        $optionLines = $resolveOptions($item);
                        $itemName = $item->product_name ?? $item->name ?? __('Item');
                        $discountLabel = $discountNameFor($item);
                    ?>
                    <div class="py-4 <?php echo e(! $loop->last ? 'border-bottom' : ''); ?>">
                        <div class="d-flex justify-content-between align-items-start gap-3 order-tracking-item">
                            <div>
                                <p class="fw-semibold mb-1"><?php echo e($itemName); ?></p>
                                <p class="text-muted small mb-2">Qty: <?php echo e($quantity); ?></p>
                                <?php $__currentLoopData = $optionLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $adjustment = $line['adjustment'] ?? 0; ?>
                                    <div class="text-warning small fw-semibold">
                                        <?php echo e($line['label']); ?>: <?php echo e($line['value']); ?>

                                                    <?php if($adjustment > 0): ?>
                                                        (+ <?php echo e(rupiah($adjustment)); ?>)
                                                    <?php elseif($adjustment < 0): ?>
                                                        (– <?php echo e(rupiah(abs($adjustment))); ?>)
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="text-end">
                                <div class="text-muted small <?php echo e($lineDiscount > 0 ? 'text-decoration-line-through' : ''); ?>">
                                    Item price: <?php echo e(rupiah($lineOriginal)); ?>

                                </div>
                                <?php if($lineDiscount > 0): ?>
                                    <div class="text-success small">
                                        Discount (<?php echo e($discountLabel ?? 'Promo'); ?>): -<?php echo e(rupiah($lineDiscount)); ?>

                                    </div>
                                <?php endif; ?>
                                <p class="fw-bold mb-0"><?php echo e(rupiah($lineFinal)); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

                        <div class="pt-3 order-tracking-totals">
                            <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                <span class="text-muted">Subtotal</span>
                                <span class="fw-semibold"><?php echo e(rupiah($totals['pre_discount_subtotal'])); ?></span>
                            </div>
                            <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                <span class="text-muted">Discount</span>
                                <span class="text-success">- <?php echo e(rupiah($totals['discount_total'])); ?></span>
                            </div>
                            <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                <span class="text-muted">Subtotal after discount</span>
                                <span class="fw-semibold"><?php echo e(rupiah($totals['subtotal'])); ?></span>
                            </div>
                            <?php $__currentLoopData = $taxLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                    <span class="text-muted">
                                        <?php echo e($taxLine->name ?? $taxLine['name'] ?? 'Tax'); ?>

                                        <?php
                                            $lineType = $taxLine->type ?? $taxLine['type'] ?? null;
                                            $lineRate = $taxLine->rate ?? $taxLine['rate'] ?? null;
                                        ?>
                                        <?php if($lineType === 'percentage' && $lineRate !== null): ?>
                                            (<?php echo e(rtrim(rtrim(number_format($lineRate, 2, '.', ''), '0'), '.')); ?>%)
                                        <?php endif; ?>
                                    </span>
                                    <span><?php echo e(rupiah($taxLine->amount ?? $taxLine['amount'] ?? 0)); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                <span class="text-muted">Total Tax</span>
                                <span><?php echo e(rupiah($totals['total_tax'])); ?></span>
                            </div>
                            <hr class="my-3">
                            <div class="d-flex justify-content-between align-items-center order-tracking-total-line">
                                <span class="fw-bold">Total (incl. tax)</span>
                                <span class="fw-bold" style="color: #f58220;"><?php echo e(rupiah($totals['grand_total'])); ?></span>
                            </div>
                            <div class="d-flex justify-content-between py-2 mt-3 order-tracking-total-line">
                                <span class="text-muted">Xendit Fee</span>
                                <span><?php echo e(rupiah($totals['xendit_fee'])); ?></span>
                            </div>
                            <div class="d-flex justify-content-between py-2 order-tracking-total-line">
                                <span class="text-muted">Platform Fee</span>
                                <span><?php echo e(rupiah($totals['qash_fee'])); ?></span>
                            </div>
                            <hr class="my-3">
                            <div class="d-flex justify-content-between align-items-center order-tracking-total-line">
                                <span class="fw-bold">Net Received</span>
                                <span class="fw-bold"><?php echo e(rupiah($totals['net'])); ?></span>
                            </div>
                        </div>

            <div class="d-flex flex-column flex-md-row gap-3 mt-4 order-tracking-actions">
                <a href="<?php echo e(route('payment.success', ['tenant' => request()->route('tenant'), 'order' => $order])); ?>"
                    class="btn btn-dark rounded-pill py-3 px-4 flex-fill fw-semibold">
                    View Invoice
                </a>
                <a href="<?php echo e(route('cart.page', ['tenant' => request()->route('tenant')])); ?>"
                    class="btn btn-outline-dark rounded-pill py-3 px-4 flex-fill fw-semibold">
                    Continue Browsing
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $attributes = $__attributesOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__attributesOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $component = $__componentOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__componentOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/payment/order-tracking.blade.php ENDPATH**/ ?>