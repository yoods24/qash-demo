<x-backoffice.layout>
    <div data-takeaway-enabled="true">
        <livewire:backoffice.kitchen-orders />
    </div>
</x-backoffice.layout>
