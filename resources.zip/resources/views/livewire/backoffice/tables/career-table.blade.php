<div>
    {{ $this->table }}
</div>

