<?php if (isset($component)) { $__componentOriginal04028366e911435fb447a8c3d2d17713 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04028366e911435fb447a8c3d2d17713 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.settings-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.settings-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $settings = $invoiceSettings ?? new \App\Models\TenantInvoiceSettings();
        $logoUrl = tenant_storage_url($settings->invoice_logo);
        $dueOptions = range(0, 60);
    ?>

    <div class="col-md-9">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div>
                        <h5 class="mb-1">Invoice Settings</h5>
                        <p class="text-muted mb-0">Customize how your invoices look before sending them to customers.</p>
                    </div>
                    <div class="invoice-settings-preview rounded-circle border bg-light d-flex align-items-center justify-content-center">
                        <?php if($logoUrl): ?>
                            <img src="<?php echo e($logoUrl); ?>" alt="Invoice Logo" class="img-fluid">
                        <?php else: ?>
                            <span class="text-muted small">Logo</span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <div class="fw-semibold mb-2">Please fix the following:</div>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('backoffice.invoice-settings.update')); ?>" enctype="multipart/form-data" class="invoice-settings-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row g-4">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Invoice Logo</label>
                            <div class="d-flex align-items-center gap-3 flex-wrap">
                                <div class="invoice-logo-box border rounded d-flex align-items-center justify-content-center bg-light">
                                    <?php if($logoUrl): ?>
                                        <img src="<?php echo e($logoUrl); ?>" alt="Invoice Logo" class="img-fluid">
                                    <?php else: ?>
                                        <span class="text-muted small">Preview</span>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <input type="file" name="invoice_logo" accept="image/*" class="form-control <?php $__errorArgs = ['invoice_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <small class="text-muted">Recommended size 450x450px. Max size 5MB.</small>
                                    <?php $__errorArgs = ['invoice_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold" for="invoice_prefix">Invoice Prefix</label>
                            <input type="text" id="invoice_prefix" name="invoice_prefix" class="form-control" placeholder="INV-" value="<?php echo e(old('invoice_prefix', $settings->invoice_prefix)); ?>">
                            <small class="text-muted">Shown before the invoice number.</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold" for="invoice_due_days">Invoice Due</label>
                            <div class="input-group">
                                <select name="invoice_due_days" id="invoice_due_days" class="form-select">
                                    <?php $__currentLoopData = $dueOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($day); ?>" <?php if(old('invoice_due_days', $settings->invoice_due_days) == $day): echo 'selected'; endif; ?>><?php echo e($day); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="input-group-text">Days</span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold d-block">Invoice Round Off</label>
                            <div class="d-flex align-items-center gap-3">
                                <input type="hidden" name="invoice_round_off" value="0">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="invoice_round_off"
                                           name="invoice_round_off" value="1" <?php if(old('invoice_round_off', $settings->invoice_round_off)): echo 'checked'; endif; ?>>
                                    <label class="form-check-label" for="invoice_round_off">Enable</label>
                                </div>
                                <select name="invoice_round_direction" class="form-select w-auto" aria-label="Round direction">
                                    <option value="up" <?php if(old('invoice_round_direction', $settings->invoice_round_direction) === 'up'): echo 'selected'; endif; ?>>Round Up</option>
                                    <option value="down" <?php if(old('invoice_round_direction', $settings->invoice_round_direction) === 'down'): echo 'selected'; endif; ?>>Round Down</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold d-block">Show Company Details</label>
                            <input type="hidden" name="show_company_details" value="0">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="show_company_details"
                                       name="show_company_details" value="1" <?php if(old('show_company_details', $settings->show_company_details)): echo 'checked'; endif; ?>>
                                <label class="form-check-label" for="show_company_details">Display tenant info on invoice</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold" for="invoice_header_terms">Invoice Header Terms</label>
                            <textarea id="invoice_header_terms" name="invoice_header_terms" rows="3" class="form-control" placeholder="Add a short message or payment instruction."><?php echo e(old('invoice_header_terms', $settings->invoice_header_terms)); ?></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold" for="invoice_footer_terms">Invoice Footer Terms</label>
                            <textarea id="invoice_footer_terms" name="invoice_footer_terms" rows="4" class="form-control" placeholder="Include thanks note, refund policy, etc."><?php echo e(old('invoice_footer_terms', $settings->invoice_footer_terms)); ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light border">Cancel</a>
                        <button type="submit" class="btn btn-main px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $attributes = $__attributesOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__attributesOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04028366e911435fb447a8c3d2d17713)): ?>
<?php $component = $__componentOriginal04028366e911435fb447a8c3d2d17713; ?>
<?php unset($__componentOriginal04028366e911435fb447a8c3d2d17713); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/settings/app/invoice-settings.blade.php ENDPATH**/ ?>