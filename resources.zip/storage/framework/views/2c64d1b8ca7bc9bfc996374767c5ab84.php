<div class="card">
    <div class="card-body">
        <div class="d-flex flex-column flex-lg-row gap-3 align-items-lg-center justify-content-between mb-3">
            <div>
                <h5 class="mb-1">Staff Attendance</h5>
                <p class="text-muted mb-0">Records for <?php echo e($this->selectedDateLabel); ?></p>
            </div>
            <div class="w-100" style="max-width: 240px;">
                <label class="form-label mb-1 text-muted small text-uppercase fw-semibold">Pick a date</label>
                <input type="date"
                       wire:model.live="selectedDate"
                       class="form-control"
                       max="<?php echo e(now()->toDateString()); ?>">
            </div>
        </div>

        <div id="fi-admin-attendance-table">
            <?php echo e($this->table); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/livewire/backoffice/tables/admin-daily-attendance-table.blade.php ENDPATH**/ ?>