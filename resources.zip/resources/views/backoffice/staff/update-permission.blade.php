<x-backoffice.layout>
    <livewire:backoffice.role-permissions-editor :role="$role" />
</x-backoffice.layout>
