<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="fw-bold">Category</h2>
      <div class="action-buttons">
        <button class="btn btn-outline-secondary">Export</button>
        <button class="btn btn-outline-secondary">More actions</button>
        <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addProductModal">
          Add Role
        </button>
      </div>
    </div>
    <div class="order-summary">
      <div class="summary-container">
          <p class="data"><?php echo e($categories->total()); ?></p>
          <p class="primer">Total Category</p>
      </div>
    </div>

    <ul class="nav nav-tabs mb-3" id="orderTabs" role="tablist">
      <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">All</button></li>
      <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#unpaid" type="button" role="tab">Unpaid</button></li>
    </ul>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.category-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-2378744074-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
      <!-- Add other tabs like #unpaid, #ship etc. as needed -->
    </div>


<?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addProductModal','title' => 'Add Category','action' => ''.e(route('backoffice.category.store')).' ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addProductModal','title' => 'Add Category','action' => ''.e(route('backoffice.category.store')).' ']); ?>
    <div class="mb-3">
        <label for="product" class="form-label">Add Category</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Category Name">
    </div>
    <div class="mb-3">
        <label for="image_url">Insert Image</label>
        <input type="file" id="image_url" name="image_url" class="form-control-file" >
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>

<!-- Modal -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/product/category.blade.php ENDPATH**/ ?>