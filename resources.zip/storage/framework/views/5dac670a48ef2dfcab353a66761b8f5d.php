<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-0">Edit Employee</h4>
            <div class="text-muted small">Update <?php echo e(trim(($staff->firstName ?? '') . ' ' . ($staff->lastName ?? ''))); ?></div>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="collapse"  data-bs-target=".multi-collapse" title="Toggle all sections"><i class="bi bi-arrows-collapse"></i></button>
            <a href="<?php echo e(route('backoffice.staff.index')); ?>" class="btn btn-primer"><i class="bi bi-arrow-left me-1"></i> Back to List</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <div class="fw-semibold mb-1">Please correct the following:</div>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php
        $dateOfBirth = $staff->date_of_birth ? \Illuminate\Support\Carbon::parse($staff->date_of_birth)->format('Y-m-d') : null;
        $joiningDate = $staff->joining_date ? \Illuminate\Support\Carbon::parse($staff->joining_date)->format('Y-m-d') : null;
    ?>

    <form action="<?php echo e(route('backoffice.staff.update', $staff)); ?>" method="POST" enctype="multipart/form-data" class="d-grid gap-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <!-- Employee Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-employee" aria-expanded="false">
                <div class="fw-bold">
                    <i class="bi bi-person-gear me-2 text-warning"></i>
                    Employee Information
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-employee" class="collapse multi-collapse form-section show">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-lg-12">
                            <div class="card-body d-flex flex-column flex-md-row align-items-center gap-3">
                                <div class="avatar-lg rounded-3 d-flex align-items-center justify-content-center bg-light-subtle border py-3 px-4 overflow-hidden" aria-label="Avatar">
                                    <?php if($staff->profile_image_url): ?>
                                        <img src="<?php echo e($staff->profile_image_url); ?>" alt="<?php echo e(trim(($staff->firstName ?? '') . ' ' . ($staff->lastName ?? ''))); ?>" style="width:100%;height:100%;object-fit:cover;">
                                    <?php else: ?>
                                        <i class="bi bi-person-fill fs-1 text-secondary"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-grow-1 w-100">
                                    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3">
                                        <div class="w-100 w-lg-auto">
                                            <label class="form-label">Profile Photo</label>
                                            <input type="file" name="profile-image" accept="image/*" class="form-control">
                                            <?php $__errorArgs = ['profile-image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">First Name <span class="red-asterisk">*</span></label>
                            <input name="firstName" value="<?php echo e(old('firstName', $staff->firstName)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Last Name <span class="red-asterisk">*</span></label>
                            <input name="lastName" value="<?php echo e(old('lastName', $staff->lastName)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Email <span class="red-asterisk">*</span></label>
                            <input type="email" name="email" value="<?php echo e(old('email', $staff->email)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Contact Number <span class="red-asterisk">*</span></label>
                            <input name="phone" value="<?php echo e(old('phone', $staff->phone)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Emp Code</label>
                            <input name="emp_code" value="<?php echo e(old('emp_code', $staff->emp_code)); ?>" class="form-control">
                            <?php $__errorArgs = ['emp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth', $dateOfBirth)); ?>" class="form-control">
                            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = ['Male','Female']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gender); ?>" <?php if(old('gender', $staff->gender) === $gender): echo 'selected'; endif; ?>><?php echo e($gender); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nationality</label>
                            <input name="nationality" value="<?php echo e(old('nationality', $staff->nationality)); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Joining Date</label>
                            <input type="date" name="joining_date" value="<?php echo e(old('joining_date', $joiningDate)); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Shift</label>
                            <select name="shift_id" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($shift->id); ?>" <?php if(old('shift_id', $staff->shift_id) == $shift->id): echo 'selected'; endif; ?>><?php echo e($shift->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['shift_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $bloodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group->value); ?>" <?php if(old('blood_group', $staff->blood_group?->value) == $group->value): echo 'selected'; endif; ?>><?php echo e($group->value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex justify-content-between">
                                <label class="form-label">Role</label>
                                <button type="button" class="text-orange" data-bs-toggle="modal" data-bs-target="#addProductModal">
                                    <i class="bi bi-plus-circle"></i>
                                    Create new role
                                </button>
                            </div>
                            <select name="role" class="form-select">
                                <option value="">Select</option>
                                <?php $currentRole = old('role', $staff->roles->first()->name ?? ''); ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>" <?php if($currentRole === $role->name): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">About</label>
                            <textarea name="about" rows="3" class="form-control"><?php echo e(old('about', $staff->about)); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Address Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-address">
                <div class="fw-bold">
                    <i class="bi bi-geo-alt me-2 text-warning"></i>
                    Address
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-address" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Address</label>
                            <input name="address" value="<?php echo e(old('address', $staff->address)); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Country</label>
                            <input name="country" value="<?php echo e(old('country', $staff->country)); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">State</label>
                            <input name="state" value="<?php echo e(old('state', $staff->state)); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <input name="city" value="<?php echo e(old('city', $staff->city)); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Zipcode</label>
                            <input name="zipcode" value="<?php echo e(old('zipcode', $staff->zipcode)); ?>" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Emergency Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-emergency">
                <div class="fw-bold">
                    <i class="bi bi-telephone-plus me-2 text-warning"></i>
                    Emergency
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-emergency" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Emergency Contact Number 1</label><input name="emergency_contact_number_1" value="<?php echo e(old('emergency_contact_number_1', $staff->emergency_contact_number_1)); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Relation</label><input name="emergency_contact_relation_1" value="<?php echo e(old('emergency_contact_relation_1', $staff->emergency_contact_relation_1)); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Name</label><input name="emergency_contact_name_1" value="<?php echo e(old('emergency_contact_name_1', $staff->emergency_contact_name_1)); ?>" class="form-control"></div>

                        <div class="col-md-4"><label class="form-label">Emergency Contact Number 2</label><input name="emergency_contact_number_2" value="<?php echo e(old('emergency_contact_number_2', $staff->emergency_contact_number_2)); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Relation</label><input name="emergency_contact_relation_2" value="<?php echo e(old('emergency_contact_relation_2', $staff->emergency_contact_relation_2)); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Name</label><input name="emergency_contact_name_2" value="<?php echo e(old('emergency_contact_name_2', $staff->emergency_contact_name_2)); ?>" class="form-control"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bank Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-bank">
                <div class="fw-bold">
                    <i class="bi bi-bank me-2 text-warning"></i>
                    Bank
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-bank" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Bank Name</label><input name="bank_name" value="<?php echo e(old('bank_name', $staff->bank_name)); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Account Number</label><input name="account_number" value="<?php echo e(old('account_number', $staff->account_number)); ?>" class="form-control"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Password -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-password">
                <div class="fw-bold">
                    <i class="bi bi-braces-asterisk me-2 text-warning"></i>
                    Password
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-password" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm new password">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
            <a href="<?php echo e(route('backoffice.staff.index')); ?>" class="btn btn-secondary">Cancel</a>
            <button class="btn btn-warning text-white">Save Changes</button>
        </div>
    </form>

    <?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addProductModal','title' => 'Tambah Role','action' => ''.e(route('backoffice.role.store-wr')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addProductModal','title' => 'Tambah Role','action' => ''.e(route('backoffice.role.store-wr')).'']); ?>
        <div class="mb-3">
            <label for="product" class="form-label">Add Role</label>
            <input type="text" class="form-control" id="role" name="role" placeholder="Masukkan Role">
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addShiftModal','title' => 'Add Shift','action' => ''.e(route('backoffice.shift.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addShiftModal','title' => 'Add Shift','action' => ''.e(route('backoffice.shift.store')).'']); ?>
        <ul class="nav nav-tabs mb-3" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-shift-info" type="button" role="tab">Shift Info</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-breaks" type="button" role="tab">Break Rules</button>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-shift-info" role="tabpanel">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Shift Name</label>
                        <input type="text" class="form-control" name="name" placeholder="e.g. Fixed 9-6" />
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">From</label>
                        <input type="time" class="form-control" name="starts_at" />
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">To</label>
                        <input type="time" class="form-control" name="ends_at" />
                    </div>
                    <div class="col-12">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="2" placeholder="Optional"></textarea>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="tab-breaks" role="tabpanel">
                <div class="row g-3">
                    <div class="col-12"><strong>Morning Break</strong></div>
                    <div class="col-6">
                        <label class="form-label">From</label>
                        <input type="time" class="form-control" name="breaks[morning][from]" />
                    </div>
                    <div class="col-6">
                        <label class="form-label">To</label>
                        <input type="time" class="form-control" name="breaks[morning][to]" />
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/staff/edit.blade.php ENDPATH**/ ?>