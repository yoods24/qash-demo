<x-backoffice.layout>
    <div class="d-flex align-items-center flex-wrap justify-content-between mb-3 mb-md-4">
        <div class="d-flex align-items-center">
            <i class="bi bi-box-seam text-orange fs-3 me-2"></i>
            <h4 class="mb-0">Products Purchase Report</h4>
        </div>
        <div class="d-flex justify-content-between gap-3">
            <div>
                <a href="{{ route('backoffice.reports.products', array_merge(request()->route()->parameters(), request()->query(), ['export' => 1])) }}" class="btn btn-warning">
                    <i class="bi bi-box-arrow-down me-1"></i> Export
                </a>
            </div>
            <div>
                <button class="btn btn-back">
                    <i class="bi bi-box-arrow-down me-1"></i> Back To Reports
                </button>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body">
            <form method="GET" action="{{ route('backoffice.reports.products', request()->route()->parameters()) }}" class="row g-2 g-md-3 align-items-end">
                <div class="col-12 col-md-3">
                    <label class="form-label">From</label>
                    <input type="date" name="from" value="{{ $from }}" class="form-control" />
                </div>
                <div class="col-12 col-md-3">
                    <label class="form-label">To</label>
                    <input type="date" name="to" value="{{ $to }}" class="form-control" />
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Any</option>
                        @foreach(['waiting_for_payment','confirmed','preparing','ready','cancelled'] as $s)
                            <option value="{{ $s }}" @selected(($status ?? null) === $s)>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label">Payment</label>
                    <select name="payment_status" class="form-select">
                        <option value="">Any</option>
                        @foreach(['pending','paid','failed','cancelled'] as $p)
                            <option value="{{ $p }}" @selected(($payment_status ?? null) === $p)>{{ ucfirst($p) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-12 text-end">
                    <button class="btn btn-outline-warning w-100"><i class="bi bi-funnel me-1"></i> Filter</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="text-muted">Date</th>
                            <th class="text-muted">Product</th>
                            <th class="text-muted">Quantity</th>
                            <th class="text-muted">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($rows as $r)
                            <tr>
                                <td>{{ $r->day }}</td>
                                <td>{{ $r->product_name }}</td>
                                <td>{{ (int) $r->quantity }}</td>
                                <td>{{ number_format((float) $r->total, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">No data for the selected period.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-backoffice.layout>
