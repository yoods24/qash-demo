<nav class="sidebar shrunk d-flex flex-column flex-shrink-0 p-3" data-lenis-prevent>
      <div class="brand-wrap d-flex align-items-center justify-content-between justify-content-md-center text-white text-decoration-none">
          <!-- Expanded: full logo | Shrunk: compact mark -->
          <img onclick="window.location='<?php echo e(route('backoffice.dashboard')); ?>'" src="<?php echo e(global_asset('storage/logos/Main Logo-Orange.png')); ?>" alt="Qash" class="brand-img brand-compact" />
          <img onclick="window.location='<?php echo e(route('backoffice.dashboard')); ?>'" src="<?php echo e(global_asset('storage/logos/Logotype-Orange.png')); ?>" alt="Qash" class="brand-img brand-full" />
        <button id="sidebarToggleMobile" title="Toggle Sidebar"><i class="bi bi-list"></i></button>
      </div>

      <?php
        $inventoryPermissions = ['inventory_products_view', 'inventory_category_view', 'inventory_special_type_view', 'inventory_sub_category_view'];
        $promoPermissions = ['promo_view', 'promo_summary_view', 'promo_code_view', 'promo_discounts_view'];
        $reportPermissions = ['reports_view', 'reports_sales_view', 'reports_inventory_view', 'reports_invoice_view', 'reports_customer_view', 'reports_product_view', 'reports_profit_loss_view', 'reports_annual_view', 'reports_kitchen_view'];
        $peoplePermissions = ['peoples_customers_view', 'peoples_view'];
        $posPermissions = ['pos_view', 'pos_orders_view', 'sales_orders_view'];
        $tablePermissions = ['tables_view', 'pos_table_orders_view', 'table_information_view', 'table_plan_view'];
        $contentPermissions = [
            'content_view',
            'content_homepage_settings_view',
            'content_select_homepage_view',
            'content_font_family_view',
            'content_auth_layout_settings_view',
            'content_header_settings_view',
            'content_select_header_view',
            'content_top_bar_view',
            'content_footer_settings_view',
            'content_pages_view',
            'content_appearance_view',
            'content_events_view',
            'content_careers_view',
            'content_about_view',
            'content_brand_information_view',
        ];
      ?>

      <div class="sidebar-wrapper">
        <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.dashboard')).'','class' => 'bi bi-grid-1x2-fill me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.dashboard')).'','class' => 'bi bi-grid-1x2-fill me-2']); ?>Dashboard <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.attendance.index')).'','class' => 'bi bi-building me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.attendance.index')).'','class' => 'bi bi-building me-2']); ?>Attendance <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Home']); ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.staff.view', ['staff' => request()->user()->id])).'','class' => 'bi bi-cash-coin me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.staff.view', ['staff' => request()->user()->id])).'','class' => 'bi bi-cash-coin me-2']); ?>Profile <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.settings.index')).'','class' => 'bi bi-gear me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.settings.index')).'','class' => 'bi bi-gear me-2']); ?>Settings <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.notification.index')).'','class' => 'bi bi-bell me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.notification.index')).'','class' => 'bi bi-bell me-2']); ?>Notification <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('taxes_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.taxes.index')).'','class' => 'bi bi-cash me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.taxes.index')).'','class' => 'bi bi-cash me-2']); ?>Taxes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($tablePermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Table']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Table']); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pos_table_orders_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.tables.index')).'','class' => 'bi bi-grid-3x3-gap-fill me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.tables.index')).'','class' => 'bi bi-grid-3x3-gap-fill me-2']); ?>Dining Tables <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('table_information_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.tables.info')).'','class' => 'bi bi-info-circle me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.tables.info')).'','class' => 'bi bi-info-circle me-2']); ?>Table Information <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('table_plan_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.tables.plan')).'','class' => 'bi bi-info-circle me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.tables.plan')).'','class' => 'bi bi-info-circle me-2']); ?>Table Plan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($inventoryPermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Inventory']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Inventory']); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory_products_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.product.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.product.index')).'','class' => 'bi bi-list-task me-2']); ?>Product <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory_category_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.category.index')).'','class' => 'bi bi-cash-coin me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.category.index')).'','class' => 'bi bi-cash-coin me-2']); ?>Category <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            
            
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($promoPermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Promo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Promo']); ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-list-task me-2']); ?>Summary <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-cash-coin me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-cash-coin me-2']); ?>Promo Code <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('promo_discounts_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.discounts.index')).'','class' => 'bi bi-gear me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.discounts.index')).'','class' => 'bi bi-gear me-2']); ?>Discounts <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($reportPermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Reports']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Reports']); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.reports.index')).'','class' => 'bi bi-graph-up me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.reports.index')).'','class' => 'bi bi-graph-up me-2']); ?>Reports <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($peoplePermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Peoples']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Peoples']); ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('peoples_customers_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.customers.index')).'','class' => 'bi bi-people me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.customers.index')).'','class' => 'bi bi-people me-2']); ?>Customers <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('peoples_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('customer.order')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('customer.order')).'','class' => 'bi bi-list-task me-2']); ?>Customer Order <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($posPermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'POS & Orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'POS & Orders']); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pos_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.pos.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.pos.index')).'','class' => 'bi bi-list-task me-2']); ?>POS <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pos_orders_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-cash-coin me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-cash-coin me-2']); ?>POS Orders <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pos_table_orders_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-gear me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-gear me-2']); ?>Table Orders <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales_orders_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.order.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.order.index')).'','class' => 'bi bi-list-task me-2']); ?>All Order <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hrm_view')): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'HRM']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'HRM']); ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.attendance.staff')).'','class' => 'bi bi-people-fill me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.attendance.staff')).'','class' => 'bi bi-people-fill me-2']); ?>Staff Attendance <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hrm_employees_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.staff.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.staff.index')).'','class' => 'bi bi-list-task me-2']); ?>All Staff <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hrm_roles_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.roles.index')).'','class' => 'bi bi-cash-coin me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.roles.index')).'','class' => 'bi bi-cash-coin me-2']); ?>Staff Permission <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hrm_shifts_view')): ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.shift.index')).'','class' => 'bi bi-building me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.shift.index')).'','class' => 'bi bi-building me-2']); ?>Shift <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-building me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-building me-2']); ?>Cuti <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['class' => 'bi bi-building me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bi bi-building me-2']); ?>Leave <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kitchen_view')): ?>
          <?php
              $kdsPendingCount = \App\Models\Order::query()
                  ->whereIn('status', ['confirmed', 'preparing'])
                  ->whereIn('order_type', ['dine-in', 'takeaway'])
                  ->count();
          ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Kitchen']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Kitchen']); ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.kitchen.index')).'','class' => 'bi bi-fork-knife me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.kitchen.index')).'','class' => 'bi bi-fork-knife me-2']); ?>
                <span class="d-inline-flex align-items-center gap-2">
                  K.D.S
                  <?php if($kdsPendingCount > 0): ?>
                    <span class="badge rounded-pill bg-danger-subtle text-danger fw-semibold ms-1"><?php echo e($kdsPendingCount); ?></span>
                  <?php endif; ?>
                </span>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
              <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.kitchen.index')).'','class' => 'bi bi-fork-knife me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.kitchen.index')).'','class' => 'bi bi-fork-knife me-2']); ?>O.S.S <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($contentPermissions)): ?>
          <?php if (isset($component)) { $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-section','data' => ['section' => 'Content (CMS)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Content (CMS)']); ?>
          <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('customer.home')).'','class' => 'bi bi-house me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('customer.home')).'','class' => 'bi bi-house me-2']); ?>Home Page <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('customer.order')).'','class' => 'bi bi-wallet me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('customer.order')).'','class' => 'bi bi-wallet me-2']); ?>Order Page <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.gallery.index')).'','class' => 'bi bi-images me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.gallery.index')).'','class' => 'bi bi-images me-2']); ?>Gallery <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_events_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.events.index')).'','class' => 'bi bi-calendar-event me-2 heroicon heroicon-o-calendar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.events.index')).'','class' => 'bi bi-calendar-event me-2 heroicon heroicon-o-calendar']); ?>Events <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_careers_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.careers.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.careers.index')).'','class' => 'bi bi-list-task me-2']); ?>Career <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_about_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.about.index')).'','class' => 'bi bi-list-task me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.about.index')).'','class' => 'bi bi-list-task me-2']); ?>About Homepage <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_brand_information_view')): ?>
            <?php if (isset($component)) { $__componentOriginalda2ed728e291ac017b31ea76b4d653cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.sidebar-nav-link','data' => ['href' => ''.e(route('backoffice.brand-information.index')).'','class' => 'bi bi-type-h1 me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('backoffice.brand-information.index')).'','class' => 'bi bi-type-h1 me-2']); ?>Brand Information <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $attributes = $__attributesOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__attributesOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb)): ?>
<?php $component = $__componentOriginalda2ed728e291ac017b31ea76b4d653cb; ?>
<?php unset($__componentOriginalda2ed728e291ac017b31ea76b4d653cb); ?>
<?php endif; ?>
          <?php endif; ?>
            
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $attributes = $__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__attributesOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6)): ?>
<?php $component = $__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6; ?>
<?php unset($__componentOriginalb2d9a8a5f9e01c03ef9fbb40bbae48a6); ?>
<?php endif; ?>
        <?php endif; ?>

        
    </nav>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/sidebar.blade.php ENDPATH**/ ?>