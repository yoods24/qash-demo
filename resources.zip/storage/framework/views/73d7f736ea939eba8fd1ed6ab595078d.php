<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-0">Add Employee</h4>
            <div class="text-muted small">Create new Employee</div>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="collapse"  data-bs-target=".multi-collapse" title="Toggle all sections"><i class="bi bi-arrows-collapse"></i></button>
            <a href="<?php echo e(route('backoffice.staff.index')); ?>" class="btn btn-primer"><i class="bi bi-arrow-left me-1"></i> Back to List</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <div class="fw-semibold mb-1">Please correct the following:</div>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('backoffice.user.store')); ?>" method="POST" enctype="multipart/form-data" class="d-grid gap-3">
        <?php echo csrf_field(); ?>
        <!-- Employee Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-employee" aria-expanded="false">
                <div class="fw-bold">
                    <i class="bi bi-person-gear me-2 text-warning"></i> 
                    Employee Information
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-employee" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-lg-12">
                            <div class="card-body d-flex flex-column flex-md-row align-items-center gap-3">
                                <div class="avatar-lg rounded-3 d-flex align-items-center justify-content-center bg-light-subtle border py-3 px-4" aria-label="Avatar">
                                    <i class="bi bi-person-fill fs-1 text-secondary"></i>
                                </div>
                                <div class="flex-grow-1 w-100">
                                    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3">
                                        <div class="w-100 w-lg-auto">
                                            <label class="form-label">Profile Photo</label>
                                            <input type="file" name="profile-image" accept="image/*" class="form-control">
                                            <?php $__errorArgs = ['profile-image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">First Name <span class="red-asterisk">*</span></label>
                            <input name="firstName" value="<?php echo e(old('firstName')); ?>" class="form-control" required>
                            <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Last Name <span class="red-asterisk">*</span></label>
                            <input name="lastName" value="<?php echo e(old('lastName')); ?>" class="form-control" required>
                            <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Email <span class="red-asterisk">*</span></label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Contact Number <span class="red-asterisk">*</span></label>
                            <input name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" required>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Emp Code</label>
                            <input name="emp_code" value="<?php echo e(old('emp_code')); ?>" class="form-control">
                            <?php $__errorArgs = ['emp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" class="form-control">
                            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option value="Male" <?php if(old('gender')==='Male'): echo 'selected'; endif; ?>>Male</option>
                                <option value="Female" <?php if(old('gender')==='Female'): echo 'selected'; endif; ?>>Female</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nationality</label>
                            <input name="nationality" value="<?php echo e(old('nationality')); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Joining Date</label>
                            <input type="date" name="joining_date" value="<?php echo e(old('joining_date')); ?>" class="form-control">
                        </div>

                        <div class="col-md-4">
                            <div class="d-flex justify-content-between">
                                <label class="form-label">Shift</label>
                                <button type="button" class="text-orange" data-bs-toggle="modal" data-bs-target="#addShiftModal">
                                    <i class="bi bi-plus-circle"></i>
                                    Create new shift
                                </button>
                            </div>
                            <select name="shift_id" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = ($shifts ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>" <?php if(old('shift_id')==$s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $bloodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bg); ?>" <?php if(old('blood_group')===$bg): echo 'selected'; endif; ?>><?php echo e($bg); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <div class="d-flex justify-content-between">
                                <label class="form-label">Role</label>
                                <button type="button" class="text-orange" data-bs-toggle="modal" data-bs-target="#addProductModal">
                                    <i class="bi bi-plus-circle"></i>
                                    Create new role
                                </button>
                            </div>
                            <select name="role" class="form-select">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">About</label>
                            <textarea name="about" rows="3" class="form-control"><?php echo e(old('about')); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Address Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-address">
                <div class="fw-bold">
                    <i class="bi bi-geo-alt me-2 text-warning"></i> 
                    Address
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-address" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Address</label>
                            <input name="address" value="<?php echo e(old('address')); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Country</label>
                            <input name="country" value="<?php echo e(old('country')); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">State</label>
                            <input name="state" value="<?php echo e(old('state')); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <input name="city" value="<?php echo e(old('city')); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Zipcode</label>
                            <input name="zipcode" value="<?php echo e(old('zipcode')); ?>" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Emergency Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-emergency">
                <div class="fw-bold">
                    <i class="bi bi-telephone-plus me-2 text-warning"></i> 
                    Emergency
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-emergency" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Emergency Contact Number 1</label><input name="emergency_contact_number_1" value="<?php echo e(old('emergency_contact_number_1')); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Relation</label><input name="emergency_contact_relation_1" value="<?php echo e(old('emergency_contact_relation_1')); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Name</label><input name="emergency_contact_name_1" value="<?php echo e(old('emergency_contact_name_1')); ?>" class="form-control"></div>

                        <div class="col-md-4"><label class="form-label">Emergency Contact Number 2</label><input name="emergency_contact_number_2" value="<?php echo e(old('emergency_contact_number_2')); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Relation</label><input name="emergency_contact_relation_2" value="<?php echo e(old('emergency_contact_relation_2')); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Name</label><input name="emergency_contact_name_2" value="<?php echo e(old('emergency_contact_name_2')); ?>" class="form-control"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bank Information -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-bank">
                <div class="fw-bold">
                    <i class="bi bi-bank me-2 text-warning"></i> 
                    Address
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-bank" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Bank Name</label><input name="bank_name" value="<?php echo e(old('bank_name')); ?>" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">Account Number</label><input name="account_number" value="<?php echo e(old('account_number')); ?>" class="form-control"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Password -->
        <div class="card">
            <div class="d-flex justify-content-between text-center align-items-center p-3 cursor-pointer"  data-bs-toggle="collapse" data-bs-target="#sec-password">
                <div class="fw-bold">
                    <i class="bi bi-braces-asterisk me-2 text-warning"></i> 
                    Password
                </div>
                <i class="bi bi-arrow-down me-2"></i>
            </div>
            <hr class="m-0">
            <div id="sec-password" class="collapse multi-collapse form-section">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Password <span class="red-asterisk">*</span></label>
                            <input type="password" name="password" class="form-control" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Confirm Password <span class="red-asterisk">*</span></label>
                            <input type="password" name="password_confirmation" class="form-control" required>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
            <a href="<?php echo e(route('backoffice.staff.index')); ?>" class="btn btn-secondary">Cancel</a>
            <button class="btn btn-warning text-white">Add Employee</button>
        </div>
    </form>

<?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addProductModal','title' => 'Tambah Role','action' => ''.e(route('backoffice.role.store-wr')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addProductModal','title' => 'Tambah Role','action' => ''.e(route('backoffice.role.store-wr')).'']); ?>
    <div class="mb-3">
        <label for="product" class="form-label">Add Role</label>
        <input type="text" class="form-control" id="role" name="role" placeholder="Masukkan Role">
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>



    <?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addShiftModal','title' => 'Add Shift','action' => ''.e(route('backoffice.shift.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addShiftModal','title' => 'Add Shift','action' => ''.e(route('backoffice.shift.store')).'']); ?>
        <ul class="nav nav-tabs mb-3" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-shift-info" type="button" role="tab">Shift Info</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-breaks" type="button" role="tab">Break Timings</button>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-shift-info" role="tabpanel">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">Shift *</label>
                        <input type="text" class="form-control" name="name" required />
                    </div>
                    <div class="col-6">
                        <label class="form-label">From *</label>
                        <input type="time" class="form-control" name="start_time" required />
                    </div>
                    <div class="col-6">
                        <label class="form-label">To *</label>
                        <input type="time" class="form-control" name="end_time" required />
                    </div>
                    <div class="col-12">
                        <label class="form-label">Weekoff</label>
                        <select class="form-select" name="week_off_days[]" multiple>
                            <option value="1">Monday</option>
                            <option value="2">Tuesday</option>
                            <option value="3">Wednesday</option>
                            <option value="4">Thursday</option>
                            <option value="5">Friday</option>
                            <option value="6">Saturday</option>
                            <option value="7">Sunday</option>
                        </select>
                        <div class="form-text">Hold Ctrl/Cmd to select multiple.</div>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Weekdays Definition</label>
                        <div class="table-responsive border rounded">
                            <table class="table mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Days</th>
                                        <th>All</th>
                                        <th>1st</th>
                                        <th>2nd</th>
                                        <th>3rd</th>
                                        <th>4th</th>
                                        <th>5th</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = [1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday',7=>'Sunday']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dVal => $dLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" name="day_rules[<?php echo e($dVal); ?>][enabled]" />
                                                    <label class="form-check-label ms-2"><?php echo e($dLabel); ?></label>
                                                </div>
                                            </td>
                                            <td><input class="form-check-input" type="checkbox" name="day_rules[<?php echo e($dVal); ?>][all]" /></td>
                                            <?php $__currentLoopData = [1,2,3,4,5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <input class="form-check-input" type="checkbox" name="day_rules[<?php echo e($dVal); ?>][weeks][]" value="<?php echo e($wk); ?>" />
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="recurring" value="1" checked />
                            <label class="form-check-label">Recurring Shift</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status">
                            <option value="active" selected>Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="tab-breaks" role="tabpanel">
                <div class="row g-3">
                    <div class="col-12"><strong>Morning Break</strong></div>
                    <div class="col-6">
                        <label class="form-label">From</label>
                        <input type="time" class="form-control" name="breaks[morning][from]" />
                    </div>
                    <div class="col-6">
                        <label class="form-label">To</label>
                        <input type="time" class="form-control" name="breaks[morning][to]" />
                    </div>

                    <div class="col-12 mt-2"><strong>Lunch</strong></div>
                    <div class="col-6">
                        <label class="form-label">From</label>
                        <input type="time" class="form-control" name="breaks[lunch][from]" />
                    </div>
                    <div class="col-6">
                        <label class="form-label">To</label>
                        <input type="time" class="form-control" name="breaks[lunch][to]" />
                    </div>

                    <div class="col-12 mt-2"><strong>Evening Break</strong></div>
                    <div class="col-6">
                        <label class="form-label">From</label>
                        <input type="time" class="form-control" name="breaks[evening][from]" />
                    </div>
                    <div class="col-6">
                        <label class="form-label">To</label>
                        <input type="time" class="form-control" name="breaks[evening][to]" />
                    </div>

                    <div class="col-12">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" rows="3" name="description"></textarea>
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>

<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/staff/create.blade.php ENDPATH**/ ?>