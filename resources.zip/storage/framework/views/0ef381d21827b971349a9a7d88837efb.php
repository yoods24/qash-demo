<?php if (isset($component)) { $__componentOriginalef98058bc140d9868c671f00a8b84914 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef98058bc140d9868c671f00a8b84914 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <section class="secondary-white">
    <div class="section-wrapper text-black" style="min-height: auto;">
      <div class="text-center mb-4">
        <p class="primer bold mb-1">OPEN POSITIONS</p>
        <h2 class="fw-bold mb-1">Find your perfect role</h2>
        <p class="text-muted mb-0">Join our team and start your journey with us.</p>
      </div>

      <div class="container px-0">
        <div class="row">
          <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.career-card-wide','data' => ['career' => $career]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer.career-card-wide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['career' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($career)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb)): ?>
<?php $attributes = $__attributesOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb; ?>
<?php unset($__attributesOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb)): ?>
<?php $component = $__componentOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb; ?>
<?php unset($__componentOriginalcd4ac427f12c5c382be3e0b3e2eb5dfb); ?>
<?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-4">
          <?php echo e($careers->links()); ?>

        </div>
      </div>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $attributes = $__attributesOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__attributesOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef98058bc140d9868c671f00a8b84914)): ?>
<?php $component = $__componentOriginalef98058bc140d9868c671f00a8b84914; ?>
<?php unset($__componentOriginalef98058bc140d9868c671f00a8b84914); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/customer/career/index.blade.php ENDPATH**/ ?>