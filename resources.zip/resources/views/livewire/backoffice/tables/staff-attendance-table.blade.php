<div id="fi-app">
    {{ $this->table }}
</div>
