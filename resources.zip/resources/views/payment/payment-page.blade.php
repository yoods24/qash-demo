<x-customer.layout>
    <livewire:payment-page :order="$order" />
</x-customer.layout>
