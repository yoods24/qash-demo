<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
    <div class="row">
        <div class="col-12 mb-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold mb-1">Discounts</h2>
                    <p class="text-muted mb-0">Plan promo rules, limit availability, and sync them with your events.</p>
                </div>
                <div class="action-buttons d-flex gap-2">
                    <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#discountCreateModal">
                        Add Discount
                    </button>
                </div>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success mt-3 mb-0">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-3 mb-0">
                    <div class="fw-semibold mb-1">Please fix the following:</div>
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-12">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.discount-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-4293171832-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>
    </div>

    <?php
        $daysList = [
            'monday' => 'Monday',
            'tuesday' => 'Tuesday',
            'wednesday' => 'Wednesday',
            'thursday' => 'Thursday',
            'friday' => 'Friday',
            'saturday' => 'Saturday',
            'sunday' => 'Sunday',
        ];
        $oldDays = old('days', []);
        $oldProducts = collect(old('products', []))->map(fn($value) => (int) $value)->all();
    ?>

    <?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'discountCreateModal','title' => 'Add Discount','action' => ''.e(route('backoffice.discounts.store', ['tenant' => $tenantParam])).'','submitLabel' => 'Add Discount']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'discountCreateModal','title' => 'Add Discount','action' => ''.e(route('backoffice.discounts.store', ['tenant' => $tenantParam])).'','submit-label' => 'Add Discount']); ?>
        <div class="row g-3">
            <div class="col-md-4">
                <label for="discount-name" class="form-label fw-semibold">Discount Name <span class="text-danger">*</span></label>
                <input 
                    type="text" 
                    class="form-control" 
                    id="discount-name" 
                    name="name" 
                    value="<?php echo e(old('name')); ?>" 
                    placeholder="New member Monday"
                    required
                >
            </div>
            <div class="col-md-4">
                <label for="discount-plan" class="form-label fw-semibold">Discount Plan <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-plan" name="quantity_type" required>
                    <option value="" disabled <?php echo e(old('quantity_type') ? '' : 'selected'); ?>>Select plan</option>
                    <option value="unlimited" <?php if(old('quantity_type', 'unlimited') === 'unlimited'): echo 'selected'; endif; ?>>Unlimited</option>
                    <option value="decrement" <?php if(old('quantity_type') === 'decrement'): echo 'selected'; endif; ?>>Decrement (per quantity)</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="discount-applicable-for" class="form-label fw-semibold">Applicable For <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-applicable-for" name="applicable_for" required>
                    <option value="" disabled <?php echo e(old('applicable_for') ? '' : 'selected'); ?>>Select option</option>
                    <option value="all" <?php if(old('applicable_for', 'all') === 'all'): echo 'selected'; endif; ?>>All Products</option>
                    <option value="specific" <?php if(old('applicable_for') === 'specific'): echo 'selected'; endif; ?>>Specific Products</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="discount-valid-from" class="form-label fw-semibold">Valid From <span class="text-danger">*</span></label>
                <input 
                    type="date" 
                    class="form-control" 
                    id="discount-valid-from" 
                    name="valid_from" 
                    value="<?php echo e(old('valid_from')); ?>"
                    required
                >
            </div>
            <div class="col-md-6">
                <label for="discount-valid-till" class="form-label fw-semibold">Valid Till <span class="text-danger">*</span></label>
                <input 
                    type="date" 
                    class="form-control" 
                    id="discount-valid-till" 
                    name="valid_till" 
                    value="<?php echo e(old('valid_till')); ?>"
                    required
                >
            </div>
            <div class="col-md-4">
                <label for="discount-type" class="form-label fw-semibold">Discount Type <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-type" name="discount_type" required>
                    <option value="" disabled <?php echo e(old('discount_type') ? '' : 'selected'); ?>>Select type</option>
                    <option value="flat" <?php if(old('discount_type', 'flat') === 'flat'): echo 'selected'; endif; ?>>Flat</option>
                    <option value="percent" <?php if(old('discount_type') === 'percent'): echo 'selected'; endif; ?>>Percent</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="discount-value" class="form-label fw-semibold">Value <span class="text-danger">*</span></label>
                <div class="input-group">
                    <input 
                        type="number" 
                        class="form-control" 
                        id="discount-value" 
                        name="value" 
                        value="<?php echo e(old('value')); ?>" 
                        step="0.01" 
                        min="0"
                        placeholder="Enter amount"
                        required
                    >
                    <span class="input-group-text" id="discount-value-suffix"><?php echo e(old('discount_type', 'flat') === 'percent' ? '%' : 'IDR'); ?></span>
                </div>
            </div>
            <div class="col-md-4">
                <label for="discount-status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-status" name="status" required>
                    <option value="active" <?php if(old('status', 'active') === 'active'): echo 'selected'; endif; ?>>Active</option>
                    <option value="inactive" <?php if(old('status') === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                </select>
            </div>

            <div class="col-12 <?php echo e(old('applicable_for', 'all') === 'specific' ? '' : 'd-none'); ?>" id="discount-products-wrapper">
                <label for="discount-products" class="form-label fw-semibold">Select Products <span class="text-danger">*</span></label>
                <select 
                    multiple 
                    class="form-select" 
                    id="discount-products" 
                    name="products[]"
                >
                    <?php $__currentLoopData = $productOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product['id']); ?>" <?php if(in_array($product['id'], $oldProducts, true)): echo 'selected'; endif; ?>>
                            <?php echo e($product['name']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-text">Hold CTRL (or CMD on Mac) to select multiple products.</div>
            </div>

            <div class="col-md-4 <?php echo e(old('quantity_type', 'unlimited') === 'decrement' ? '' : 'd-none'); ?>" id="discount-quantity-wrapper">
                <label for="discount-quantity" class="form-label fw-semibold">Quantity</label>
                <input 
                    type="number" 
                    class="form-control" 
                    id="discount-quantity" 
                    name="quantity" 
                    value="<?php echo e(old('quantity')); ?>" 
                    min="1"
                >
            </div>

            <div class="col-12">
                <label class="form-label fw-semibold d-block mb-2">Valid on Following Days <span class="text-danger">*</span></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = $daysList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input 
                                class="form-check-input" 
                                type="checkbox" 
                                value="<?php echo e($key); ?>" 
                                id="day-<?php echo e($key); ?>" 
                                name="days[]" 
                                <?php if(in_array($key, $oldDays, true)): echo 'checked'; endif; ?>
                            >
                            <label class="form-check-label" for="day-<?php echo e($key); ?>">
                                <?php echo e($label); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldb0d68c8f75c99077e7217096a8bcb0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb0d68c8f75c99077e7217096a8bcb0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.update','data' => ['id' => 'discountUpdateModal','title' => 'Update Discount','action' => route('backoffice.discounts.update', ['tenant' => $tenantParam, 'discount' => '__discount__']),'submitLabel' => 'Save Changes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.update'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'discountUpdateModal','title' => 'Update Discount','action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('backoffice.discounts.update', ['tenant' => $tenantParam, 'discount' => '__discount__'])),'submit-label' => 'Save Changes']); ?>
        <div class="row g-3">
            <div class="col-md-4">
                <label for="discount-update-name" class="form-label fw-semibold">Discount Name <span class="text-danger">*</span></label>
                <input
                    type="text"
                    class="form-control"
                    id="discount-update-name"
                    name="name"
                    placeholder="New member Monday"
                    required
                >
            </div>
            <div class="col-md-4">
                <label for="discount-update-plan" class="form-label fw-semibold">Discount Plan <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-update-plan" name="quantity_type" required>
                    <option value="" disabled selected>Select plan</option>
                    <option value="unlimited">Unlimited</option>
                    <option value="decrement">Decrement (per quantity)</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="discount-update-applicable-for" class="form-label fw-semibold">Applicable For <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-update-applicable-for" name="applicable_for" required>
                    <option value="" disabled selected>Select option</option>
                    <option value="all">All Products</option>
                    <option value="specific">Specific Products</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="discount-update-valid-from" class="form-label fw-semibold">Valid From <span class="text-danger">*</span></label>
                <input
                    type="date"
                    class="form-control"
                    id="discount-update-valid-from"
                    name="valid_from"
                    required
                >
            </div>
            <div class="col-md-6">
                <label for="discount-update-valid-till" class="form-label fw-semibold">Valid Till <span class="text-danger">*</span></label>
                <input
                    type="date"
                    class="form-control"
                    id="discount-update-valid-till"
                    name="valid_till"
                    required
                >
            </div>
            <div class="col-md-4">
                <label for="discount-update-type" class="form-label fw-semibold">Discount Type <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-update-type" name="discount_type" required>
                    <option value="flat">Flat (IDR)</option>
                    <option value="percent">Percent (%)</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="discount-update-value" class="form-label fw-semibold">Discount Value <span class="text-danger">*</span></label>
                <div class="input-group">
                    <input
                        type="number"
                        class="form-control"
                        id="discount-update-value"
                        name="value"
                        step="0.01"
                        min="0"
                        placeholder="Enter amount"
                        required
                    >
                    <span class="input-group-text" id="discount-update-value-suffix">IDR</span>
                </div>
            </div>
            <div class="col-md-4">
                <label for="discount-update-status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                <select class="form-select" id="discount-update-status" name="status" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>

            <div class="col-12 d-none" id="discount-update-products-wrapper">
                <label for="discount-update-products" class="form-label fw-semibold">Select Products <span class="text-danger">*</span></label>
                <select
                    multiple
                    class="form-select"
                    id="discount-update-products"
                    name="products[]"
                >
                    <?php $__currentLoopData = $productOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product['id']); ?>">
                            <?php echo e($product['name']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-text">Hold CTRL (or CMD on Mac) to select multiple products.</div>
            </div>

            <div class="col-md-4 d-none" id="discount-update-quantity-wrapper">
                <label for="discount-update-quantity" class="form-label fw-semibold">Quantity</label>
                <input
                    type="number"
                    class="form-control"
                    id="discount-update-quantity"
                    name="quantity"
                    min="1"
                >
            </div>

            <div class="col-12">
                <label class="form-label fw-semibold d-block mb-2">Valid on Following Days <span class="text-danger">*</span></label>
                <div class="d-flex flex-wrap gap-3" id="discount-update-days">
                    <?php $__currentLoopData = $daysList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                value="<?php echo e($key); ?>"
                                id="discount-update-day-<?php echo e($key); ?>"
                                name="days[]"
                            >
                            <label class="form-check-label" for="discount-update-day-<?php echo e($key); ?>">
                                <?php echo e($label); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb0d68c8f75c99077e7217096a8bcb0a)): ?>
<?php $attributes = $__attributesOriginaldb0d68c8f75c99077e7217096a8bcb0a; ?>
<?php unset($__attributesOriginaldb0d68c8f75c99077e7217096a8bcb0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb0d68c8f75c99077e7217096a8bcb0a)): ?>
<?php $component = $__componentOriginaldb0d68c8f75c99077e7217096a8bcb0a; ?>
<?php unset($__componentOriginaldb0d68c8f75c99077e7217096a8bcb0a); ?>
<?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const applicableSelect = document.getElementById('discount-applicable-for');
            const productsWrapper = document.getElementById('discount-products-wrapper');
            const planSelect = document.getElementById('discount-plan');
            const quantityWrapper = document.getElementById('discount-quantity-wrapper');
            const discountTypeSelect = document.getElementById('discount-type');
            const valueSuffix = document.getElementById('discount-value-suffix');

            const toggleProducts = () => {
                if (applicableSelect.value === 'specific') {
                    productsWrapper?.classList.remove('d-none');
                } else {
                    productsWrapper?.classList.add('d-none');
                }
            };

            const toggleQuantity = () => {
                if (planSelect.value === 'decrement') {
                    quantityWrapper?.classList.remove('d-none');
                } else {
                    quantityWrapper?.classList.add('d-none');
                }
            };

            const updateValueSuffix = () => {
                valueSuffix.textContent = discountTypeSelect.value === 'percent' ? '%' : 'IDR';
            };

            applicableSelect?.addEventListener('change', toggleProducts);
            planSelect?.addEventListener('change', toggleQuantity);
            discountTypeSelect?.addEventListener('change', updateValueSuffix);

            toggleProducts();
            toggleQuantity();
            updateValueSuffix();
        });
    </script>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/promo/discount-index.blade.php ENDPATH**/ ?>