<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex flex-wrap justify-content-between align-items-end mb-3 gap-2">
        <div>
            <h4 class="mb-1">Dining Tables</h4>
            <div class="text-muted small">Arrange and manage tables for tenant <?php echo e(tenant('id')); ?></div>
        </div>
    </div>
    <div class="row g-3">
        <div class="col-12">
            <div class="card card-white p-3">
                <div class="fw-semibold mb-2">Selected Table</div>
                <form id="editTableForm" class="row g-2 align-items-end" autocomplete="off">
                    <input type="hidden" name="id" id="tableId" />
                    <div class="col">
                        <label class="form-label">Label</label>
                        <input type="text" class="form-control w-100" id="tableLabel" name="label" placeholder="Table A" />
                    </div>
                    <div class="col">
                        <label class="form-label">Status</label>
                        <select class="form-select w-100" id="tableStatus" name="status">
                            <option value="available">Available</option>
                            <option value="occupied">Occupied</option>
                            <option value="oncleaning">On Cleaning</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>
                    <div class="col">
                        <label class="form-label">Shape</label>
                        <select class="form-select w-100" id="tableShape" name="shape">
                            <option value="rectangle">Rectangle</option>
                            <option value="circle">Circle</option>
                        </select>
                    </div>
                    <div class="col">
                        <label class="form-label">Capacity</label>
                        <input type="number" class="form-control w-100" id="tableCapacity" name="capacity" min="1" max="50" />
                    </div>
                    <div class="col">
                        <label class="form-label">Color</label>
                        <input type="color" class="form-control form-control-color w-50" id="tableColor" name="color" value="#f1f5f9" />
                    </div>
                <div class="small text-muted mt-4 justify-content-between d-flex text-center align-items-center">
                    Tip: Click a table tile or the pencil icon to edit.
                    <div>
                        <button type="button" id="deleteTableBtn" class="btn btn-outline-danger btn-sm" disabled>Delete</button>
                        <button type="submit" class="btn btn-primer btn-sm" disabled>Save</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
        <div class="col-12">
            <div class="ms-auto d-flex gap-2 p-3 justify-content-between">
                <div class="mb-3">
                    <?php $selected = $currentFloorId ?? null; ?>
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('backoffice.tables.index', ['tenant' => tenant('id'), 'floor' => $f->id])); ?>"
                            class="btn btn-sm <?php echo e($selected === $f->id ? 'btn-primary' : 'btn-outline-primary'); ?>">
                                <?php echo e($f->name); ?>

                                <?php if($f->area_type): ?>
                                    <span class="badge bg-light text-dark ms-1"><?php echo e($f->area_type); ?></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#addFloorModal">
                            <i class="bi bi-plus-lg me-1"></i> Add Floor
                        </button>

                        <?php if(($floors->count() ?? 0) > 0): ?>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-danger dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Manage Selected
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <form action="<?php echo e(route('backoffice.floors.update', ['tenant' => tenant('id'), 'floor' => $selected])); ?>" method="POST" class="px-3 py-2 d-grid gap-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="text" name="name" class="form-control form-control-sm" placeholder="Rename floor" required>
                                        <input type="text" name="area_type" class="form-control form-control-sm" placeholder="Area type">
                                        <button type="submit" class="btn btn-sm btn-outline-primary">Save</button>
                                    </form>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <?php if(($floors->count() ?? 0) > 1): ?>
                                    <li>
                                        <form action="<?php echo e(route('backoffice.floors.destroy', ['tenant' => tenant('id'), 'floor' => $selected])); ?>" method="POST" class="px-3 py-2">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger w-100">Delete Floor</button>
                                        </form>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div>
                    <button id="addTableBtn" type="button" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-plus-lg me-1"></i> Add Table
                    </button>
                </div>
            </div>
            <div class="card card-white p-2">
                <div class="grid-stack" id="tablesGrid"
                     data-store-url="<?php echo e(route('backoffice.tables.store')); ?>"
                     data-positions-url="<?php echo e(route('backoffice.tables.positions')); ?>"
                     data-update-url-template="<?php echo e(rtrim(route('backoffice.tables.update', ['dining_table' => 0]), '0')); ?>"
                     data-destroy-url-template="<?php echo e(rtrim(route('backoffice.tables.destroy', ['dining_table' => 0]), '0')); ?>"
                     data-csrf="<?php echo e(csrf_token()); ?>"
                     data-floor-id="<?php echo e($currentFloorId); ?>"
                >
                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="grid-stack-item" data-id="<?php echo e($t->id); ?>" data-label="<?php echo e($t->label); ?>" data-status="<?php echo e($t->status); ?>" data-shape="<?php echo e($t->shape); ?>" data-capacity="<?php echo e($t->capacity); ?>" data-color="<?php echo e($t->color); ?>"
                             gs-x="<?php echo e(max(0, (int)($t->x ?? 0))); ?>" gs-y="<?php echo e(max(0, (int)($t->y ?? 0))); ?>" gs-w="<?php echo e(max(1, (int)($t->w ?: 2))); ?>" gs-h="<?php echo e(max(1, (int)($t->h ?: 2))); ?>">
                            <?php
                                $status = strtolower($t->status);
                                $borderColor = match($status) {
                                    'available' => '#16a34a',
                                    'occupied' => '#dc2626',
                                    'oncleaning' => '#f59e0b',
                                    'archived' => '#111827',
                                    default => '#e2e8f0',
                                };
                            ?>
                            <div class="grid-stack-item-content d-flex flex-column justify-content-center align-items-center"
                                 style="background: <?php echo e($t->color ?: '#f1f5f9'); ?>; border: 2px solid <?php echo e($borderColor); ?>; border-radius: <?php echo e($t->shape === 'circle' ? '50%' : '0.5rem'); ?>; <?php echo e($t->shape === 'circle' ? 'aspect-ratio:1/1;' : ''); ?>">
                                <div class="fw-semibold"><?php echo e($t->label); ?></div>
                                <div class="small text-muted"><?php echo e(ucfirst($t->status)); ?> <?php echo e($t->capacity); ?> seats</div>
                                <button class="btn btn-sm btn-outline-secondary mt-2 edit-table-btn" data-id="<?php echo e($t->id); ?>">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="form-text text-muted mt-2 d-flex justify-content-between align-items-center mt-3">
                Drag and resize tables; click Save Layout to persist positions.
                <div>
                    <button id="saveLayoutBtn" type="button" class="btn btn-sm btn-success">
                        <i class="bi bi-save me-1"></i> Save Layout
                    </button>
            </div>
        </div>
    </div>

    <!-- Add Floor Modal -->
    <div class="modal fade" id="addFloorModal" tabindex="-1" aria-labelledby="addFloorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addFloorModalLabel">Add New Floor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('backoffice.floors.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body d-grid gap-3">
                        <div>
                            <label class="form-label">Floor Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Floor 2" required>
                        </div>
                        <div>
                            <label class="form-label">Area Type</label>
                            <input type="text" name="area_type" class="form-control" placeholder="indoor / outdoor">
                        </div>
                        <div>
                            <label class="form-label">Auto-create Tables (capacities)</label>
                            <input type="text" name="auto_tables" class="form-control" value="1,4,6">
                            <div class="form-text">Comma/space separated capacities. Defaults to 1,4,6.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Floor</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/tables.js'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>


<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/tables/index.blade.php ENDPATH**/ ?>