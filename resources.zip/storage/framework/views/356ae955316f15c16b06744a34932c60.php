<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="fw-bold">Career</h2>
    <div class="action-buttons d-flex gap-2">
      <a href="<?php echo e(route('backoffice.career.create')); ?>" class="btn btn-add">
        Add Career
      </a>
    </div>
  </div>

  <div class="order-summary mb-3">
    <div><strong>Total career:</strong> <?php echo e($careerData->total()); ?></div>
    <div><strong>Total minimum salary per month:</strong> Rp<?php echo e(number_format($totalSalary, 0, ',', '.')); ?></div>
  </div>

  <div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.career-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-3554911784-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/career/index.blade.php ENDPATH**/ ?>