  <div class="tab-content" id="orderTabsContent">
    <div class="tab-pane fade show active" id="all" role="tabpanel">
      <div class="table-responsive">
        <table class="table table-hover align-middle order-table">
          <thead class="table-light">
            <tr>
                {{$thead}}
            </tr>
          </thead>
          <tbody>
            {{$tbody}}
          </tbody>
        </table>
      </div>