<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Mobile orientation guard: visible only on phones in portrait via JS -->
    <div id="rotateOverlay" class="d-none position-fixed top-0 start-0 w-100 h-100 p-4" style="z-index:2000; background: rgba(255,255,255,0.98);">
        <div class="h-100 d-flex flex-column align-items-center justify-content-center text-center">
            <i class="bi bi-phone-landscape" style="font-size: 3rem;"></i>
            <h5 class="mt-2 mb-1">Rotate to Landscape</h5>
            <div class="text-muted">For the table plan, please rotate your device horizontally.</div>
        </div>
    </div>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.plan-board');

$__html = app('livewire')->mount($__name, $__params, 'lw-1614025380-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <script>
        (function(){
            const overlay = document.getElementById('rotateOverlay');
            if (!overlay) return;
            function small() { return window.matchMedia('(max-width: 991.98px)').matches; }
            function portrait() { const m = window.matchMedia('(orientation: portrait)'); return (m && typeof m.matches==='boolean') ? m.matches : (innerHeight > innerWidth); }
            function toggle(){ overlay.classList.toggle('d-none', !(small() && portrait())); }
            toggle();
            window.addEventListener('resize', toggle);
            window.addEventListener('orientationchange', toggle);
        })();
</script>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/tables/plan.blade.php ENDPATH**/ ?>