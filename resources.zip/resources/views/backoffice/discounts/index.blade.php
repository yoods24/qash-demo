<x-backoffice.layout>
    <div class="container-fluid py-4">
        @livewire(\App\Filament\Tenant\Pages\Discounts\DiscountIndex::class)
    </div>
</x-backoffice.layout>
