<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="fw-bold">Product</h2>
      <div class="action-buttons">
        <button class="btn btn-outline-secondary">Export</button>
        <button class="btn btn-outline-secondary">More actions</button>
        <a href="<?php echo e(route('backoffice.product.create')); ?>" class="btn btn-add" >
          Add Product
        </a>
      </div>
    </div>
    <div class="order-summary">
      <div class="summary-container">
          <p class="data"><?php echo e($products->total()); ?></p>
          <p class="primer">Total Product</p>
      </div>
      <div class="summary-container">
          <p class="data">5</p>
          <p class="primer">Low On Stock</p>
      </div>
      <div class="summary-container">
          <p class="data">Non Coffee</p>
          <p class="primer">Best Category</p>
      </div>
    </div>

    <div>
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.products-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-3389838684-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

      <!-- Add other tabs like #unpaid, #ship etc. as needed -->
    </div>
<!-- Modal -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/product/index.blade.php ENDPATH**/ ?>