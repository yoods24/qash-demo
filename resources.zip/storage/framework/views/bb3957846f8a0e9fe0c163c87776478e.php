<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Dashboard - Qash</title>
    <script>
      // Initialize theme early to avoid flash
      (function() {
        try {
          var key = 'qash:theme';
          var saved = localStorage.getItem(key);
          var theme = saved || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
          document.documentElement.dataset.theme = theme;
          document.documentElement.classList.toggle('dark', theme === 'dark');
        } catch (e) { /* no-op */ }
      })();
    </script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Splide slider CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/css/splide.min.css">
    
    <link rel="icon" href="<?php echo e(global_asset('storage/logos/Qash_single_logogram.png')); ?>" type="image/png">

    <?php echo app('Illuminate\Foundation\Vite')([
      'resources/css/backoffice.css',
      'resources/js/backoffice.js',
      'resources/css/app.css',
      'resources/js/app.js',
      'resources/css/filament.css',
      // Keep Bootstrap collapse semantics authoritative
      'resources/css/overrides.css',
    ]); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>
  <?php echo $__env->make('components.logo-loader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="d-flex">
    <!-- Main content -->
    <div class="flex-grow-1 layout-main">
      <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginal003a14bb94bd6abec9ce6f20f2311e26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal003a14bb94bd6abec9ce6f20f2311e26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.navbar-only','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.navbar-only'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal003a14bb94bd6abec9ce6f20f2311e26)): ?>
<?php $attributes = $__attributesOriginal003a14bb94bd6abec9ce6f20f2311e26; ?>
<?php unset($__attributesOriginal003a14bb94bd6abec9ce6f20f2311e26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal003a14bb94bd6abec9ce6f20f2311e26)): ?>
<?php $component = $__componentOriginal003a14bb94bd6abec9ce6f20f2311e26; ?>
<?php unset($__componentOriginal003a14bb94bd6abec9ce6f20f2311e26); ?>
<?php endif; ?>
      <!-- Dashboard content -->
      <div class="p-4 bg-main">
        <?php echo $__env->make('components.toast-delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('notifications');

$__html = app('livewire')->mount($__name, $__params, 'lw-2380195908-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php echo e($slot); ?>

      </div>
      <?php if (isset($component)) { $__componentOriginal2b3245a5746dec4123f46f887cebc745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b3245a5746dec4123f46f887cebc745 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.delete','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b3245a5746dec4123f46f887cebc745)): ?>
<?php $attributes = $__attributesOriginal2b3245a5746dec4123f46f887cebc745; ?>
<?php unset($__attributesOriginal2b3245a5746dec4123f46f887cebc745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b3245a5746dec4123f46f887cebc745)): ?>
<?php $component = $__componentOriginal2b3245a5746dec4123f46f887cebc745; ?>
<?php unset($__componentOriginal2b3245a5746dec4123f46f887cebc745); ?>
<?php endif; ?>
      <?php if (isset($component)) { $__componentOriginal961b438607a1c503702196df17d175a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal961b438607a1c503702196df17d175a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.cancel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal961b438607a1c503702196df17d175a1)): ?>
<?php $attributes = $__attributesOriginal961b438607a1c503702196df17d175a1; ?>
<?php unset($__attributesOriginal961b438607a1c503702196df17d175a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal961b438607a1c503702196df17d175a1)): ?>
<?php $component = $__componentOriginal961b438607a1c503702196df17d175a1; ?>
<?php unset($__componentOriginal961b438607a1c503702196df17d175a1); ?>
<?php endif; ?>
    </div>
  </div>
  <?php echo $__env->yieldPushContent('scripts'); ?>
  <!-- Splide slider JS -->
  <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/js/splide.min.js"></script>
  <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/navbar-only-layout.blade.php ENDPATH**/ ?>