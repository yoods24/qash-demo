<?php if (isset($component)) { $__componentOriginal1b97f717c8e6f39e79163903b5c29937 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b97f717c8e6f39e79163903b5c29937 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backoffice.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backoffice.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h2 class="fw-bold">Taxes</h2>
                        <p class="text-muted mb-0">Create PPN, service fees, and other tenant-specific taxes.</p>
                    </div>
                    <div class="action-buttons">
                        <button class="btn btn-outline-secondary">Export</button>
                        <button class="btn btn-outline-secondary">More actions</button>
                        <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            Add Tax
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backoffice.tables.taxes-table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1930444567-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php if (isset($component)) { $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.create','data' => ['id' => 'addProductModal','title' => 'Add Tax','action' => ''.e(route('backoffice.taxes.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addProductModal','title' => 'Add Tax','action' => ''.e(route('backoffice.taxes.store')).'']); ?>
    
    
    <div class="mb-3">
        <label for="tax_name" class="form-label">Name <span class="text-danger">*</span></label>
        <input 
            type="text" 
            class="form-control" 
            id="tax_name" 
            name="name" 
            placeholder="VAT, Service Fee, etc." 
            required
        >
    </div>

    
    <div class="mb-3">
        <label for="tax_type" class="form-label">Type <span class="text-danger">*</span></label>
        <select 
            class="form-select" 
            id="tax_type" 
            name="type" 
            required
        >
            <option value="" selected disabled>Select an option</option>
            <option value="percentage">Percentage</option>
            <option value="fixed">Fixed Amount</option>
        </select>
    </div>

    
    <div class="mb-3">
        <label for="tax_rate" class="form-label">Rate <span class="text-danger">*</span></label>

        <div class="input-group">
            <input 
                type="number" 
                step="0.01" 
                min="0"
                class="form-control"
                id="tax_rate"
                name="rate"
                placeholder="10 for 10%, or 1000 for fixed amount"
                required
            >
            <span class="input-group-text" id="rateSuffix">%</span>
        </div>

        
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                const typeSelect = document.getElementById("tax_type");
                const suffix = document.getElementById("rateSuffix");

                typeSelect.addEventListener("change", function () {
                    suffix.innerText = this.value === "percentage" ? "%" : "Rp";
                });
            });
        </script>
    </div>

    
    <div class="form-check form-switch mb-3">
        <input type="hidden" name="is_active" value="0">
        <input 
            class="form-check-input" 
            type="checkbox" 
            role="switch" 
            id="tax_active" 
            name="is_active"
            value="1"
            checked
        >
        <label class="form-check-label" for="tax_active">Active</label>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $attributes = $__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__attributesOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a)): ?>
<?php $component = $__componentOriginal5e95fd19ec3bdbd14e5e65006596274a; ?>
<?php unset($__componentOriginal5e95fd19ec3bdbd14e5e65006596274a); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $attributes = $__attributesOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__attributesOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b97f717c8e6f39e79163903b5c29937)): ?>
<?php $component = $__componentOriginal1b97f717c8e6f39e79163903b5c29937; ?>
<?php unset($__componentOriginal1b97f717c8e6f39e79163903b5c29937); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/backoffice/taxes/index.blade.php ENDPATH**/ ?>