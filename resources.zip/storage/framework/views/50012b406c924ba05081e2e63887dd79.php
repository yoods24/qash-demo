<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['note']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['note']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $bgColor = 'bg-secondary';
    $iconType = 'bi-bell text-secondary';

    if (str_contains($note->type, 'order')) {
        $bgColor = 'bg-warning';
        $iconType = 'bi-fork-knife text-white';
    } elseif (str_contains($note->type, 'product')) {
        $bgColor = 'bg-success';
        $iconType = 'bi-box-seam text-white';
    } elseif (str_contains($note->type, 'warning')) {
        $bgColor = 'bg-warning';
        $iconType = 'bi-exclamation-triangle text-dark';
    }
?>

<div class="rounded-circle <?php echo e($bgColor); ?> d-inline-flex align-items-center justify-content-center"
     style="width: 36px; height: 36px;">
    <i class="bi <?php echo e($iconType); ?>"></i>
</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/backoffice/notification/notification-icon.blade.php ENDPATH**/ ?>