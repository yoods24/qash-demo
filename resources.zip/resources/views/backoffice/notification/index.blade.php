<x-backoffice.layout>
    <livewire:backoffice.notification-page>
</x-backoffice.layout>
