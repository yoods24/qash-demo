<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'id',
  'title',
  'action' => '#',
  'submitLabel' => 'Update',
  'method' => 'PUT',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'id',
  'title',
  'action' => '#',
  'submitLabel' => 'Update',
  'method' => 'PUT',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="<?php echo e($id); ?>Label" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content" data-lenis-prevent>
      <div class="modal-header update">
        <h5 class="modal-title" id="<?php echo e($id); ?>Label"><?php echo e($title); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form 
        method="POST" 
        action="<?php echo e($action); ?>" 
        enctype="multipart/form-data" 
        data-modal-form="<?php echo e($id); ?>"
        data-action-template="<?php echo e($action); ?>"
      >
        <?php echo csrf_field(); ?>
        <?php if(strtoupper($method) !== 'POST'): ?>
          <?php echo method_field($method); ?>
        <?php endif; ?>
        <div class="modal-body">
          <?php echo e($slot); ?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-outline-success"><?php echo e($submitLabel); ?></button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/modal/update.blade.php ENDPATH**/ ?>