<x-backoffice.navbar-only-layout>
    <livewire:backoffice.pos-page />

</x-backoffice.navbar-only-layout>


