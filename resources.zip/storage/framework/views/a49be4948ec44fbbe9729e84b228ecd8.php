<?php if(session('message')): ?>
<div id="toast" class="toast-success-container show d-flex flex-column justify-content-between">
    <div class="d-flex justify-content-between align-items-center">
        <span class="toast-success-icon">
            <i class="bi bi-check-circle-fill"></i>
        </span>
        <p class="m-0 ms-2 flex-grow-1 text-black"><strong><?php echo e(session('message')); ?></strong></p>
        
    </div>
    <div class="toast-progress"></div>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/components/toast-delete.blade.php ENDPATH**/ ?>