<div class="fi-app">
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Users\nadhi\Herd\Qash\resources\views/livewire/backoffice/tables/discount-table.blade.php ENDPATH**/ ?>